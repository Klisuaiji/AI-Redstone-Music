execute if score music_progress nbs_s matches 17280..17520 if score music_progress nbs_t matches ..215 run function minecraft:music/fanwutuobang_demo/notes/216
