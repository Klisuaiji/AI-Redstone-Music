execute if score music_progress nbs_s matches 22080..22400 run function minecraft:music/fanwutuobang_demo/tree/276_277
execute if score music_progress nbs_s matches 22240..22640 run function minecraft:music/fanwutuobang_demo/tree/278_279
