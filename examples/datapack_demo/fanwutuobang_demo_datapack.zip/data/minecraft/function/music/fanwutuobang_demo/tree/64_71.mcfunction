execute if score music_progress nbs_s matches 5120..5600 run function minecraft:music/fanwutuobang_demo/tree/64_67
execute if score music_progress nbs_s matches 5440..6000 run function minecraft:music/fanwutuobang_demo/tree/68_71
