execute if score music_progress nbs_s matches 5280..5680 run function minecraft:music/fanwutuobang_demo/tree/66_67
