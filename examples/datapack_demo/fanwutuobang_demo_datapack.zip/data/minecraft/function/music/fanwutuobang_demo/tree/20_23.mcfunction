execute if score music_progress nbs_s matches 1600..1920 run function minecraft:music/fanwutuobang_demo/tree/20_21
