execute if score music_progress nbs_s matches 8320..8800 run function minecraft:music/fanwutuobang_demo/tree/104_107
execute if score music_progress nbs_s matches 8640..9200 run function minecraft:music/fanwutuobang_demo/tree/108_111
