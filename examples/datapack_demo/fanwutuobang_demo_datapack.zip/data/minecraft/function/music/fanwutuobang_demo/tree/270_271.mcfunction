execute if score music_progress nbs_s matches 21600..21840 if score music_progress nbs_t matches ..270 run function minecraft:music/fanwutuobang_demo/notes/271
