execute if score music_progress nbs_s matches 21440..21760 run function minecraft:music/fanwutuobang_demo/tree/268_269
execute if score music_progress nbs_s matches 21600..22000 run function minecraft:music/fanwutuobang_demo/tree/270_271
