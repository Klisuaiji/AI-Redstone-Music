execute if score music_progress nbs_s matches 4800..5120 run function minecraft:music/fanwutuobang_demo/tree/60_61
