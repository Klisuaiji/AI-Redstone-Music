execute if score music_progress nbs_s matches 27200..27440 if score music_progress nbs_t matches ..339 run function minecraft:music/fanwutuobang_demo/notes/340
