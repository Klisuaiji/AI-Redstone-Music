execute if score music_progress nbs_s matches 3840..4160 run function minecraft:music/fanwutuobang_demo/tree/48_49
execute if score music_progress nbs_s matches 4000..4400 run function minecraft:music/fanwutuobang_demo/tree/50_51
