execute if score music_progress nbs_s matches 19040..19280 if score music_progress nbs_t matches ..237 run function minecraft:music/fanwutuobang_demo/notes/238
