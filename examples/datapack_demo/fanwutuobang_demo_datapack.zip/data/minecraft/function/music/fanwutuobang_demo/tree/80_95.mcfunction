execute if score music_progress nbs_s matches 6400..7200 run function minecraft:music/fanwutuobang_demo/tree/80_87
execute if score music_progress nbs_s matches 7040..7920 run function minecraft:music/fanwutuobang_demo/tree/88_95
