execute if score music_progress nbs_s matches 17760..18000 if score music_progress nbs_t matches ..222 run function minecraft:music/fanwutuobang_demo/notes/223
