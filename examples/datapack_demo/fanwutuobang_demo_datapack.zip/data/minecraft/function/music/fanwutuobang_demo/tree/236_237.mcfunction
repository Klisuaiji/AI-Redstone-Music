execute if score music_progress nbs_s matches 18880..19120 if score music_progress nbs_t matches ..235 run function minecraft:music/fanwutuobang_demo/notes/236
