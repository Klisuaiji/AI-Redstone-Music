execute if score music_progress nbs_s matches 19840..20160 run function minecraft:music/fanwutuobang_demo/tree/248_249
execute if score music_progress nbs_s matches 20000..20400 run function minecraft:music/fanwutuobang_demo/tree/250_251
