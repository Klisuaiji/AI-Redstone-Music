execute if score music_progress nbs_s matches 23680..24160 run function minecraft:music/fanwutuobang_demo/tree/296_299
execute if score music_progress nbs_s matches 24000..24560 run function minecraft:music/fanwutuobang_demo/tree/300_303
