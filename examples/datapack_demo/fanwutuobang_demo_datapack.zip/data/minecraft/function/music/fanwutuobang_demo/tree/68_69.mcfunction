execute if score music_progress nbs_s matches 5440..5680 if score music_progress nbs_t matches ..67 run function minecraft:music/fanwutuobang_demo/notes/68
