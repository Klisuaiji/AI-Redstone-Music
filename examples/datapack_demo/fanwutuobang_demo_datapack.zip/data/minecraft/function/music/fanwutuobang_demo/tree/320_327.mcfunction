execute if score music_progress nbs_s matches 25600..26080 run function minecraft:music/fanwutuobang_demo/tree/320_323
