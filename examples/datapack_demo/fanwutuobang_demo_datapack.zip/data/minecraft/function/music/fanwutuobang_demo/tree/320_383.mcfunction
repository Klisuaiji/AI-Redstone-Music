execute if score music_progress nbs_s matches 25600..28320 run function minecraft:music/fanwutuobang_demo/tree/320_351
