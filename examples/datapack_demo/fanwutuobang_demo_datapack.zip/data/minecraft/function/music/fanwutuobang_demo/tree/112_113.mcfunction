execute if score music_progress nbs_s matches 8960..9200 if score music_progress nbs_t matches ..112 run function minecraft:music/fanwutuobang_demo/notes/113
