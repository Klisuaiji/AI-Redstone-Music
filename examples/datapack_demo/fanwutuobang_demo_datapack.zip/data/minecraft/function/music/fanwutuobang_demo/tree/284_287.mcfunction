execute if score music_progress nbs_s matches 22880..23280 run function minecraft:music/fanwutuobang_demo/tree/286_287
