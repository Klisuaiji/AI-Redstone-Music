execute if score music_progress nbs_s matches 1280..1760 run function minecraft:music/fanwutuobang_demo/tree/16_19
execute if score music_progress nbs_s matches 1600..2160 run function minecraft:music/fanwutuobang_demo/tree/20_23
