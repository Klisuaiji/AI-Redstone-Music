execute if score music_progress nbs_s matches 16480..16720 if score music_progress nbs_t matches ..205 run function minecraft:music/fanwutuobang_demo/notes/206
