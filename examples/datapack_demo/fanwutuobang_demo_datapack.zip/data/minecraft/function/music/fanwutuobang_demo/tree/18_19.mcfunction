execute if score music_progress nbs_s matches 1440..1680 if score music_progress nbs_t matches ..17 run function minecraft:music/fanwutuobang_demo/notes/18
