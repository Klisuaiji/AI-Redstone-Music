execute if score music_progress nbs_s matches 480..880 run function minecraft:music/fanwutuobang_demo/tree/6_7
