execute if score music_progress nbs_s matches 14880..15120 if score music_progress nbs_t matches ..185 run function minecraft:music/fanwutuobang_demo/notes/186
