execute if score music_progress nbs_s matches 10240..12960 run function minecraft:music/fanwutuobang_demo/tree/128_159
execute if score music_progress nbs_s matches 12800..15600 run function minecraft:music/fanwutuobang_demo/tree/160_191
