execute if score music_progress nbs_s matches 0..20640 run function minecraft:music/fanwutuobang_demo/tree/0_255
execute if score music_progress nbs_s matches 20480..41200 run function minecraft:music/fanwutuobang_demo/tree/256_511
