execute if score music_progress nbs_s matches 12800..13120 run function minecraft:music/fanwutuobang_demo/tree/160_161
