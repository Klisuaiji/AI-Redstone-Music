execute if score music_progress nbs_s matches 24320..24800 run function minecraft:music/fanwutuobang_demo/tree/304_307
execute if score music_progress nbs_s matches 24640..25200 run function minecraft:music/fanwutuobang_demo/tree/308_311
