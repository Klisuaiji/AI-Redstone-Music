execute if score music_progress nbs_s matches 15680..16000 run function minecraft:music/fanwutuobang_demo/tree/196_197
execute if score music_progress nbs_s matches 15840..16240 run function minecraft:music/fanwutuobang_demo/tree/198_199
