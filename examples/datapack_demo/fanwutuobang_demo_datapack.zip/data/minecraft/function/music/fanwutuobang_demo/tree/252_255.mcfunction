execute if score music_progress nbs_s matches 20160..20480 run function minecraft:music/fanwutuobang_demo/tree/252_253
