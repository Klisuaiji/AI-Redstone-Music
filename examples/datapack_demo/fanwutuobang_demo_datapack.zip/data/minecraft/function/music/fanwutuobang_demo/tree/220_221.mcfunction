execute if score music_progress nbs_s matches 17600..17840 if score music_progress nbs_t matches ..220 run function minecraft:music/fanwutuobang_demo/notes/221
