execute if score music_progress nbs_s matches 1280..1520 if score music_progress nbs_t matches ..15 run function minecraft:music/fanwutuobang_demo/notes/16
