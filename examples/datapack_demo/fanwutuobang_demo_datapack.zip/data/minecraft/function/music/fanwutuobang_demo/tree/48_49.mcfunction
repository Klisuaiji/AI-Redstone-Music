execute if score music_progress nbs_s matches 3840..4080 if score music_progress nbs_t matches ..47 run function minecraft:music/fanwutuobang_demo/notes/48
