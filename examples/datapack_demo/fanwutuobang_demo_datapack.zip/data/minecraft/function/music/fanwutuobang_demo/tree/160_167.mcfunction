execute if score music_progress nbs_s matches 12800..13280 run function minecraft:music/fanwutuobang_demo/tree/160_163
execute if score music_progress nbs_s matches 13120..13680 run function minecraft:music/fanwutuobang_demo/tree/164_167
