execute if score music_progress nbs_s matches 16640..16960 run function minecraft:music/fanwutuobang_demo/tree/208_209
execute if score music_progress nbs_s matches 16800..17200 run function minecraft:music/fanwutuobang_demo/tree/210_211
