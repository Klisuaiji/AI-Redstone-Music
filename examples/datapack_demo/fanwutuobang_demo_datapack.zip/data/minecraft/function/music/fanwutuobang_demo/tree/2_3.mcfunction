execute if score music_progress nbs_s matches 160..400 if score music_progress nbs_t matches ..2 run function minecraft:music/fanwutuobang_demo/notes/3
