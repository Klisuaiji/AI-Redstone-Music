execute if score music_progress nbs_s matches 15360..16160 run function minecraft:music/fanwutuobang_demo/tree/192_199
execute if score music_progress nbs_s matches 16000..16880 run function minecraft:music/fanwutuobang_demo/tree/200_207
