execute if score music_progress nbs_s matches 14400..14640 if score music_progress nbs_t matches ..180 run function minecraft:music/fanwutuobang_demo/notes/181
