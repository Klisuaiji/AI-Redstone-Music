execute if score music_progress nbs_s matches 18560..18800 if score music_progress nbs_t matches ..232 run function minecraft:music/fanwutuobang_demo/notes/233
