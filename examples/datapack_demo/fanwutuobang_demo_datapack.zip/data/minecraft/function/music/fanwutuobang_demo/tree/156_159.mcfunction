execute if score music_progress nbs_s matches 12480..12800 run function minecraft:music/fanwutuobang_demo/tree/156_157
execute if score music_progress nbs_s matches 12640..13040 run function minecraft:music/fanwutuobang_demo/tree/158_159
