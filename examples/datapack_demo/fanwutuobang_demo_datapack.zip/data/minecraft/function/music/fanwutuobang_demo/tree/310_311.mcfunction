execute if score music_progress nbs_s matches 24800..25040 if score music_progress nbs_t matches ..310 run function minecraft:music/fanwutuobang_demo/notes/311
