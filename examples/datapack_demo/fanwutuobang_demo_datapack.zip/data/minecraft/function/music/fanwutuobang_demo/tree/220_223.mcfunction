execute if score music_progress nbs_s matches 17600..17920 run function minecraft:music/fanwutuobang_demo/tree/220_221
execute if score music_progress nbs_s matches 17760..18160 run function minecraft:music/fanwutuobang_demo/tree/222_223
