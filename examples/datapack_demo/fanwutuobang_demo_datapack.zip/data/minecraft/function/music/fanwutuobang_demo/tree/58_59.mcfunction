execute if score music_progress nbs_s matches 4640..4880 if score music_progress nbs_t matches ..57 run function minecraft:music/fanwutuobang_demo/notes/58
