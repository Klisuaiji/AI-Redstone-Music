execute if score music_progress nbs_s matches 5120..6560 run function minecraft:music/fanwutuobang_demo/tree/64_79
execute if score music_progress nbs_s matches 6400..7920 run function minecraft:music/fanwutuobang_demo/tree/80_95
