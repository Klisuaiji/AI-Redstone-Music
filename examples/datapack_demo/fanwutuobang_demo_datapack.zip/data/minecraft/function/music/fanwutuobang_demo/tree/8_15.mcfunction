execute if score music_progress nbs_s matches 640..1120 run function minecraft:music/fanwutuobang_demo/tree/8_11
