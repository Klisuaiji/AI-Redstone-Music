execute if score music_progress nbs_s matches 6080..6320 if score music_progress nbs_t matches ..75 run function minecraft:music/fanwutuobang_demo/notes/76
