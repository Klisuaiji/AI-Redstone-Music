execute if score music_progress nbs_s matches 6880..7120 if score music_progress nbs_t matches ..85 run function minecraft:music/fanwutuobang_demo/notes/86
