execute if score music_progress nbs_s matches 3840..4320 run function minecraft:music/fanwutuobang_demo/tree/48_51
