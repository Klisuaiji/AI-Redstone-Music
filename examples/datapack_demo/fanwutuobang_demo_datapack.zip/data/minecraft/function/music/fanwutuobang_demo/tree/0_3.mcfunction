execute if score music_progress nbs_s matches 0..320 run function minecraft:music/fanwutuobang_demo/tree/0_1
execute if score music_progress nbs_s matches 160..560 run function minecraft:music/fanwutuobang_demo/tree/2_3
