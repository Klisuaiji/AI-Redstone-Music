execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 1 0.529732 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.harp voice @s ^0 ^ ^ 1 1.059463 1
scoreboard players set music_progress nbs_t 6
