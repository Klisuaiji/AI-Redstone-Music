execute if score music_progress nbs_s matches 24000..24240 if score music_progress nbs_t matches ..300 run function minecraft:music/fanwutuobang_demo/notes/301
