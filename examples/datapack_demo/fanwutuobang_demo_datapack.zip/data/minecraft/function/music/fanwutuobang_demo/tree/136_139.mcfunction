execute if score music_progress nbs_s matches 10880..11200 run function minecraft:music/fanwutuobang_demo/tree/136_137
execute if score music_progress nbs_s matches 11040..11440 run function minecraft:music/fanwutuobang_demo/tree/138_139
