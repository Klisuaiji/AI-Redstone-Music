execute if score music_progress nbs_s matches 20000..20240 if score music_progress nbs_t matches ..250 run function minecraft:music/fanwutuobang_demo/notes/251
