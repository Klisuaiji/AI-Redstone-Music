execute if score music_progress nbs_s matches 24480..24880 run function minecraft:music/fanwutuobang_demo/tree/306_307
