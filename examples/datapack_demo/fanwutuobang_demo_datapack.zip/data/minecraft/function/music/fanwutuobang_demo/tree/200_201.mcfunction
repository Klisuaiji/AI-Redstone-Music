execute if score music_progress nbs_s matches 16000..16240 if score music_progress nbs_t matches ..200 run function minecraft:music/fanwutuobang_demo/notes/201
