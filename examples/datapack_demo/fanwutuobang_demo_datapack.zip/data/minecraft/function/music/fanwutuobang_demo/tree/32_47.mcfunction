execute if score music_progress nbs_s matches 2560..3360 run function minecraft:music/fanwutuobang_demo/tree/32_39
execute if score music_progress nbs_s matches 3200..4080 run function minecraft:music/fanwutuobang_demo/tree/40_47
