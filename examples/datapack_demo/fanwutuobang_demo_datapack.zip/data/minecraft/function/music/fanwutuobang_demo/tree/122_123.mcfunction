execute if score music_progress nbs_s matches 9760..10000 if score music_progress nbs_t matches ..122 run function minecraft:music/fanwutuobang_demo/notes/123
