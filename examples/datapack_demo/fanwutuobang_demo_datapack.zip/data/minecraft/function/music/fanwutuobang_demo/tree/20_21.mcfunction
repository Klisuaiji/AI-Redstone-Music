execute if score music_progress nbs_s matches 1600..1840 if score music_progress nbs_t matches ..20 run function minecraft:music/fanwutuobang_demo/notes/21
