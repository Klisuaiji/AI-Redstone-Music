execute if score music_progress nbs_s matches 16640..17440 run function minecraft:music/fanwutuobang_demo/tree/208_215
execute if score music_progress nbs_s matches 17280..18160 run function minecraft:music/fanwutuobang_demo/tree/216_223
