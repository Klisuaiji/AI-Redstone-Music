execute if score music_progress nbs_s matches 15840..16080 if score music_progress nbs_t matches ..197 run function minecraft:music/fanwutuobang_demo/notes/198
