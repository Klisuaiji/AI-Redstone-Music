execute if score music_progress nbs_s matches 23200..23440 if score music_progress nbs_t matches ..290 run function minecraft:music/fanwutuobang_demo/notes/291
