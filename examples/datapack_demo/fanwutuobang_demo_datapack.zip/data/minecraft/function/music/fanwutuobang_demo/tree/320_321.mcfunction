execute if score music_progress nbs_s matches 25600..25840 if score music_progress nbs_t matches ..320 run function minecraft:music/fanwutuobang_demo/notes/321
