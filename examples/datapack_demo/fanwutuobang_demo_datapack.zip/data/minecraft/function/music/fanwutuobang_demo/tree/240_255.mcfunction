execute if score music_progress nbs_s matches 19200..20000 run function minecraft:music/fanwutuobang_demo/tree/240_247
execute if score music_progress nbs_s matches 19840..20720 run function minecraft:music/fanwutuobang_demo/tree/248_255
