execute if score music_progress nbs_s matches 7040..7280 if score music_progress nbs_t matches ..87 run function minecraft:music/fanwutuobang_demo/notes/88
