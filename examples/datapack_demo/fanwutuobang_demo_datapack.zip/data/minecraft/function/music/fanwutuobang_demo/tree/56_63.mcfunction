execute if score music_progress nbs_s matches 4480..4960 run function minecraft:music/fanwutuobang_demo/tree/56_59
execute if score music_progress nbs_s matches 4800..5360 run function minecraft:music/fanwutuobang_demo/tree/60_63
