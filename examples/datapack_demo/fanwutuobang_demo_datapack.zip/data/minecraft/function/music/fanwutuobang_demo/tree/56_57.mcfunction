execute if score music_progress nbs_s matches 4480..4720 if score music_progress nbs_t matches ..55 run function minecraft:music/fanwutuobang_demo/notes/56
