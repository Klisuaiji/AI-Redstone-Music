execute if score music_progress nbs_s matches 24480..24720 if score music_progress nbs_t matches ..305 run function minecraft:music/fanwutuobang_demo/notes/306
