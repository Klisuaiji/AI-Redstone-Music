execute if score music_progress nbs_s matches 26720..27120 run function minecraft:music/fanwutuobang_demo/tree/334_335
