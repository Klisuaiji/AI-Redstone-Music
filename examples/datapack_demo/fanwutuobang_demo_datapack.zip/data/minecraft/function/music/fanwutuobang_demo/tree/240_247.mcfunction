execute if score music_progress nbs_s matches 19200..19680 run function minecraft:music/fanwutuobang_demo/tree/240_243
execute if score music_progress nbs_s matches 19520..20080 run function minecraft:music/fanwutuobang_demo/tree/244_247
