execute if score music_progress nbs_s matches 4480..4800 run function minecraft:music/fanwutuobang_demo/tree/56_57
execute if score music_progress nbs_s matches 4640..5040 run function minecraft:music/fanwutuobang_demo/tree/58_59
