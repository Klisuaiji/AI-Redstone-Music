execute if score music_progress nbs_s matches 20480..21920 run function minecraft:music/fanwutuobang_demo/tree/256_271
execute if score music_progress nbs_s matches 21760..23280 run function minecraft:music/fanwutuobang_demo/tree/272_287
