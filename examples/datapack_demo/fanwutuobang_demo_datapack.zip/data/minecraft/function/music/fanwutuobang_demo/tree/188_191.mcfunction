execute if score music_progress nbs_s matches 15200..15600 run function minecraft:music/fanwutuobang_demo/tree/190_191
