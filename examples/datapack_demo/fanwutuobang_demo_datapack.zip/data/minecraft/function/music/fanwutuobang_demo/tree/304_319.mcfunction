execute if score music_progress nbs_s matches 24320..25120 run function minecraft:music/fanwutuobang_demo/tree/304_311
execute if score music_progress nbs_s matches 24960..25840 run function minecraft:music/fanwutuobang_demo/tree/312_319
