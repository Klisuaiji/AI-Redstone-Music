execute if score music_progress nbs_s matches 11200..11440 if score music_progress nbs_t matches ..140 run function minecraft:music/fanwutuobang_demo/notes/141
