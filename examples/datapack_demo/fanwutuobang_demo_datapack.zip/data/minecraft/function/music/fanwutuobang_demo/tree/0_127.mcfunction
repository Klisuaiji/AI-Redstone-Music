execute if score music_progress nbs_s matches 0..5280 run function minecraft:music/fanwutuobang_demo/tree/0_63
execute if score music_progress nbs_s matches 5120..10480 run function minecraft:music/fanwutuobang_demo/tree/64_127
