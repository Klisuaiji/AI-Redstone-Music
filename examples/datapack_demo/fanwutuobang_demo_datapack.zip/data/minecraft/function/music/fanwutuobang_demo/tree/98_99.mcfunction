execute if score music_progress nbs_s matches 7840..8080 if score music_progress nbs_t matches ..97 run function minecraft:music/fanwutuobang_demo/notes/98
