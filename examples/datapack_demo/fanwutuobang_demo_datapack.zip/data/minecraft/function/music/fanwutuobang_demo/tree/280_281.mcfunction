execute if score music_progress nbs_s matches 22400..22640 if score music_progress nbs_t matches ..280 run function minecraft:music/fanwutuobang_demo/notes/281
