execute if score music_progress nbs_s matches 11200..11520 run function minecraft:music/fanwutuobang_demo/tree/140_141
