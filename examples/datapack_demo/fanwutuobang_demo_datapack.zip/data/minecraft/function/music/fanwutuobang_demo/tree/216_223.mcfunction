execute if score music_progress nbs_s matches 17280..17760 run function minecraft:music/fanwutuobang_demo/tree/216_219
execute if score music_progress nbs_s matches 17600..18160 run function minecraft:music/fanwutuobang_demo/tree/220_223
