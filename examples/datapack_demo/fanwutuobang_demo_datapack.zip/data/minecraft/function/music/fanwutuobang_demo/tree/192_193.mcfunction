execute if score music_progress nbs_s matches 15360..15600 if score music_progress nbs_t matches ..192 run function minecraft:music/fanwutuobang_demo/notes/193
