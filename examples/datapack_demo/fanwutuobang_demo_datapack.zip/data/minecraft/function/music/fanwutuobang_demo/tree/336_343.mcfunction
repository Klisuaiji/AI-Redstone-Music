execute if score music_progress nbs_s matches 27200..27760 run function minecraft:music/fanwutuobang_demo/tree/340_343
