execute if score music_progress nbs_s matches 22400..22720 run function minecraft:music/fanwutuobang_demo/tree/280_281
execute if score music_progress nbs_s matches 22560..22960 run function minecraft:music/fanwutuobang_demo/tree/282_283
