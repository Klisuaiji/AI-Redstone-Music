execute if score music_progress nbs_s matches 25280..25600 run function minecraft:music/fanwutuobang_demo/tree/316_317
execute if score music_progress nbs_s matches 25440..25840 run function minecraft:music/fanwutuobang_demo/tree/318_319
