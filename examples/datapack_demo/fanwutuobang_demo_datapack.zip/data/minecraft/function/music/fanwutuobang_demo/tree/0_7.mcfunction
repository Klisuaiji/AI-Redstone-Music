execute if score music_progress nbs_s matches 0..480 run function minecraft:music/fanwutuobang_demo/tree/0_3
execute if score music_progress nbs_s matches 320..880 run function minecraft:music/fanwutuobang_demo/tree/4_7
