execute if score music_progress nbs_s matches 15360..16800 run function minecraft:music/fanwutuobang_demo/tree/192_207
execute if score music_progress nbs_s matches 16640..18160 run function minecraft:music/fanwutuobang_demo/tree/208_223
