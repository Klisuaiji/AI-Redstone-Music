execute if score music_progress nbs_s matches 5760..6240 run function minecraft:music/fanwutuobang_demo/tree/72_75
execute if score music_progress nbs_s matches 6080..6640 run function minecraft:music/fanwutuobang_demo/tree/76_79
