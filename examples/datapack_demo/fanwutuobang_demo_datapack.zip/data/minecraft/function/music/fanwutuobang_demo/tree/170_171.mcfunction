execute if score music_progress nbs_s matches 13600..13840 if score music_progress nbs_t matches ..170 run function minecraft:music/fanwutuobang_demo/notes/171
