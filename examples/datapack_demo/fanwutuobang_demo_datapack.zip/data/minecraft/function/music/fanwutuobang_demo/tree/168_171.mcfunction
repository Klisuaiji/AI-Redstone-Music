execute if score music_progress nbs_s matches 13600..14000 run function minecraft:music/fanwutuobang_demo/tree/170_171
