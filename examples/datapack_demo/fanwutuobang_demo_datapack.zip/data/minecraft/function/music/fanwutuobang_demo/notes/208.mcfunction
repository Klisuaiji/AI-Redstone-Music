execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.hat voice @s ^0 ^ ^ 0.25 1.000000 1
scoreboard players set music_progress nbs_t 208
