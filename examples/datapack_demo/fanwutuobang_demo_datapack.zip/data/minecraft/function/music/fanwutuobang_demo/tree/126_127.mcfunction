execute if score music_progress nbs_s matches 10080..10320 if score music_progress nbs_t matches ..125 run function minecraft:music/fanwutuobang_demo/notes/126
