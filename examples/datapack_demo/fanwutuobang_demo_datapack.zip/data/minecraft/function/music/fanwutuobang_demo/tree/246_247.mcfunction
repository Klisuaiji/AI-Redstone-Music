execute if score music_progress nbs_s matches 19680..19920 if score music_progress nbs_t matches ..245 run function minecraft:music/fanwutuobang_demo/notes/246
