execute if score music_progress nbs_s matches 23040..23280 if score music_progress nbs_t matches ..287 run function minecraft:music/fanwutuobang_demo/notes/288
