execute if score music_progress nbs_s matches 8000..8240 if score music_progress nbs_t matches ..100 run function minecraft:music/fanwutuobang_demo/notes/101
