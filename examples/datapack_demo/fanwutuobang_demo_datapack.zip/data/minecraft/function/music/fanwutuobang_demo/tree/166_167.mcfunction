execute if score music_progress nbs_s matches 13280..13520 if score music_progress nbs_t matches ..165 run function minecraft:music/fanwutuobang_demo/notes/166
