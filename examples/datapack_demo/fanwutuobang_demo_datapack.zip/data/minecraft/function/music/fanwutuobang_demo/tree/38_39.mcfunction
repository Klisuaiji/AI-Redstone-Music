execute if score music_progress nbs_s matches 3040..3280 if score music_progress nbs_t matches ..37 run function minecraft:music/fanwutuobang_demo/notes/38
