execute if score music_progress nbs_s matches 4800..5040 if score music_progress nbs_t matches ..60 run function minecraft:music/fanwutuobang_demo/notes/61
