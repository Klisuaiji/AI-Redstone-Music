execute if score music_progress nbs_s matches 22880..23120 if score music_progress nbs_t matches ..285 run function minecraft:music/fanwutuobang_demo/notes/286
