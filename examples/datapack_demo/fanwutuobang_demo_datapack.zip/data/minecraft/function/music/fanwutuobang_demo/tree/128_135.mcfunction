execute if score music_progress nbs_s matches 10240..10720 run function minecraft:music/fanwutuobang_demo/tree/128_131
