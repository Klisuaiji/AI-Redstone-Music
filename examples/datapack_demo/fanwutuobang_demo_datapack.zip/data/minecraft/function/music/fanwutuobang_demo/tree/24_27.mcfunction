execute if score music_progress nbs_s matches 2080..2480 run function minecraft:music/fanwutuobang_demo/tree/26_27
