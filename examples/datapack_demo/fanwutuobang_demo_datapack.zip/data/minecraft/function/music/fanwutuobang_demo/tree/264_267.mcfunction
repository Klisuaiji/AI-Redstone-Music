execute if score music_progress nbs_s matches 21280..21680 run function minecraft:music/fanwutuobang_demo/tree/266_267
