execute if score music_progress nbs_s matches 21440..21680 if score music_progress nbs_t matches ..267 run function minecraft:music/fanwutuobang_demo/notes/268
