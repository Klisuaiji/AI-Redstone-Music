execute if score music_progress nbs_s matches 2560..2880 run function minecraft:music/fanwutuobang_demo/tree/32_33
