execute if score music_progress nbs_s matches 9600..9840 if score music_progress nbs_t matches ..120 run function minecraft:music/fanwutuobang_demo/notes/121
