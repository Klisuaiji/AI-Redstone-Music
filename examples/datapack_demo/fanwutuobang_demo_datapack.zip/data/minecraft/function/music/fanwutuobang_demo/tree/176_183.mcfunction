execute if score music_progress nbs_s matches 14080..14560 run function minecraft:music/fanwutuobang_demo/tree/176_179
execute if score music_progress nbs_s matches 14400..14960 run function minecraft:music/fanwutuobang_demo/tree/180_183
