execute if score music_progress nbs_s matches 12160..12640 run function minecraft:music/fanwutuobang_demo/tree/152_155
execute if score music_progress nbs_s matches 12480..13040 run function minecraft:music/fanwutuobang_demo/tree/156_159
