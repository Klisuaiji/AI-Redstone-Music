execute if score music_progress nbs_s matches 7680..9120 run function minecraft:music/fanwutuobang_demo/tree/96_111
execute if score music_progress nbs_s matches 8960..10480 run function minecraft:music/fanwutuobang_demo/tree/112_127
