execute if score music_progress nbs_s matches 16800..17040 if score music_progress nbs_t matches ..210 run function minecraft:music/fanwutuobang_demo/notes/211
