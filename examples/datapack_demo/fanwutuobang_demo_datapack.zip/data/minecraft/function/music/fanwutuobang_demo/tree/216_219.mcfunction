execute if score music_progress nbs_s matches 17280..17600 run function minecraft:music/fanwutuobang_demo/tree/216_217
execute if score music_progress nbs_s matches 17440..17840 run function minecraft:music/fanwutuobang_demo/tree/218_219
