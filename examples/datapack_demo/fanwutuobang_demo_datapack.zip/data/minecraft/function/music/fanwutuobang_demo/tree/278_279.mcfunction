execute if score music_progress nbs_s matches 22240..22480 if score music_progress nbs_t matches ..277 run function minecraft:music/fanwutuobang_demo/notes/278
