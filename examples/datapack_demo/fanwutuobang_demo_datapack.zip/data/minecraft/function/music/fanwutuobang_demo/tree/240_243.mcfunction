execute if score music_progress nbs_s matches 19200..19520 run function minecraft:music/fanwutuobang_demo/tree/240_241
execute if score music_progress nbs_s matches 19360..19760 run function minecraft:music/fanwutuobang_demo/tree/242_243
