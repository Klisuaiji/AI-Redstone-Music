execute if score music_progress nbs_s matches 7680..8160 run function minecraft:music/fanwutuobang_demo/tree/96_99
execute if score music_progress nbs_s matches 8000..8560 run function minecraft:music/fanwutuobang_demo/tree/100_103
