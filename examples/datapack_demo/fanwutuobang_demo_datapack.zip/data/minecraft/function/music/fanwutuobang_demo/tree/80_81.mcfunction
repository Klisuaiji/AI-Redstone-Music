execute if score music_progress nbs_s matches 6400..6640 if score music_progress nbs_t matches ..80 run function minecraft:music/fanwutuobang_demo/notes/81
