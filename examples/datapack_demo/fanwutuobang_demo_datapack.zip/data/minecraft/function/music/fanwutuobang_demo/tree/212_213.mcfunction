execute if score music_progress nbs_s matches 16960..17200 if score music_progress nbs_t matches ..212 run function minecraft:music/fanwutuobang_demo/notes/213
