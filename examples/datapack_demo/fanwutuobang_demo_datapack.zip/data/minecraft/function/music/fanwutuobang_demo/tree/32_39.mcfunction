execute if score music_progress nbs_s matches 2560..3040 run function minecraft:music/fanwutuobang_demo/tree/32_35
execute if score music_progress nbs_s matches 2880..3440 run function minecraft:music/fanwutuobang_demo/tree/36_39
