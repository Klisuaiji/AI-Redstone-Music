execute if score music_progress nbs_s matches 10240..10480 if score music_progress nbs_t matches ..127 run function minecraft:music/fanwutuobang_demo/notes/128
