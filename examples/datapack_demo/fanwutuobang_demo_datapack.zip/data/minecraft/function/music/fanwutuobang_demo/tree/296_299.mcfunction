execute if score music_progress nbs_s matches 23680..24000 run function minecraft:music/fanwutuobang_demo/tree/296_297
execute if score music_progress nbs_s matches 23840..24240 run function minecraft:music/fanwutuobang_demo/tree/298_299
