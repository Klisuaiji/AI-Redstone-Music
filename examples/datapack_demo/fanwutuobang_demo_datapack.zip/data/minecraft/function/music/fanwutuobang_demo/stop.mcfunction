scoreboard players set music_progress nbs_s 0
scoreboard players reset music_progress nbs_t
