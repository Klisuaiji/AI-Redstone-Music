execute if score music_progress nbs_s matches 25600..25920 run function minecraft:music/fanwutuobang_demo/tree/320_321
