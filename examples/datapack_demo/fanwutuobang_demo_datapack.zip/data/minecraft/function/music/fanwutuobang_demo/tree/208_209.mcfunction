execute if score music_progress nbs_s matches 16640..16880 if score music_progress nbs_t matches ..207 run function minecraft:music/fanwutuobang_demo/notes/208
