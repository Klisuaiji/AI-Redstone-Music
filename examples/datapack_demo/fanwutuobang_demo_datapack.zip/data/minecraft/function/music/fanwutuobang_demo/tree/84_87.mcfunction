execute if score music_progress nbs_s matches 6880..7280 run function minecraft:music/fanwutuobang_demo/tree/86_87
