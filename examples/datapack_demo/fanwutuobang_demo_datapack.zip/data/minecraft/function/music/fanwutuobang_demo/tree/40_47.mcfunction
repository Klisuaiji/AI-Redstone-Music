execute if score music_progress nbs_s matches 3200..3680 run function minecraft:music/fanwutuobang_demo/tree/40_43
execute if score music_progress nbs_s matches 3520..4080 run function minecraft:music/fanwutuobang_demo/tree/44_47
