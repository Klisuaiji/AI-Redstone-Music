execute if score music_progress nbs_s matches 25600..27040 run function minecraft:music/fanwutuobang_demo/tree/320_335
execute if score music_progress nbs_s matches 26880..28400 run function minecraft:music/fanwutuobang_demo/tree/336_351
