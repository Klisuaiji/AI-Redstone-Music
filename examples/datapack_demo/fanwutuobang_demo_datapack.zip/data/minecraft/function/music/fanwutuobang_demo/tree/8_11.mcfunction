execute if score music_progress nbs_s matches 640..960 run function minecraft:music/fanwutuobang_demo/tree/8_9
execute if score music_progress nbs_s matches 800..1200 run function minecraft:music/fanwutuobang_demo/tree/10_11
