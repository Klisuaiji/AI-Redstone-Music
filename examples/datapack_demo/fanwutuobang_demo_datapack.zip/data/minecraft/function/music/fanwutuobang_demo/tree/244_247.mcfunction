execute if score music_progress nbs_s matches 19680..20080 run function minecraft:music/fanwutuobang_demo/tree/246_247
