execute if score music_progress nbs_s matches 3840..4640 run function minecraft:music/fanwutuobang_demo/tree/48_55
execute if score music_progress nbs_s matches 4480..5360 run function minecraft:music/fanwutuobang_demo/tree/56_63
