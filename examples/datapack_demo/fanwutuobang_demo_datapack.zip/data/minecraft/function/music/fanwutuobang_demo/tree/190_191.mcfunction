execute if score music_progress nbs_s matches 15200..15440 if score music_progress nbs_t matches ..190 run function minecraft:music/fanwutuobang_demo/notes/191
