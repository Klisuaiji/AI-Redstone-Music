execute if score music_progress nbs_s matches 16000..16320 run function minecraft:music/fanwutuobang_demo/tree/200_201
execute if score music_progress nbs_s matches 16160..16560 run function minecraft:music/fanwutuobang_demo/tree/202_203
