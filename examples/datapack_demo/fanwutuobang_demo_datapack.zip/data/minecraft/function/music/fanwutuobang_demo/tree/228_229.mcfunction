execute if score music_progress nbs_s matches 18240..18480 if score music_progress nbs_t matches ..227 run function minecraft:music/fanwutuobang_demo/notes/228
