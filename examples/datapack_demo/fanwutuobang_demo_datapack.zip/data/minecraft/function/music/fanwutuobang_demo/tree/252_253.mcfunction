execute if score music_progress nbs_s matches 20160..20400 if score music_progress nbs_t matches ..252 run function minecraft:music/fanwutuobang_demo/notes/253
