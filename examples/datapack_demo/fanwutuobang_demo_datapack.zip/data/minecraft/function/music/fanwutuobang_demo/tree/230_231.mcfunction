execute if score music_progress nbs_s matches 18400..18640 if score music_progress nbs_t matches ..230 run function minecraft:music/fanwutuobang_demo/notes/231
