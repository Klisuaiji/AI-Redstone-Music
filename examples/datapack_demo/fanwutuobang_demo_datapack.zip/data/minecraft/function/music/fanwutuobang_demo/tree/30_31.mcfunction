execute if score music_progress nbs_s matches 2400..2640 if score music_progress nbs_t matches ..30 run function minecraft:music/fanwutuobang_demo/notes/31
