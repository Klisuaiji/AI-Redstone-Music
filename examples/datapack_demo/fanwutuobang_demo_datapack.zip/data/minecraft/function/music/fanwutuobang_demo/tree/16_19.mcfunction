execute if score music_progress nbs_s matches 1280..1600 run function minecraft:music/fanwutuobang_demo/tree/16_17
execute if score music_progress nbs_s matches 1440..1840 run function minecraft:music/fanwutuobang_demo/tree/18_19
