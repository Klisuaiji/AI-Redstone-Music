execute if score music_progress nbs_s matches 3200..3520 run function minecraft:music/fanwutuobang_demo/tree/40_41
execute if score music_progress nbs_s matches 3360..3760 run function minecraft:music/fanwutuobang_demo/tree/42_43
