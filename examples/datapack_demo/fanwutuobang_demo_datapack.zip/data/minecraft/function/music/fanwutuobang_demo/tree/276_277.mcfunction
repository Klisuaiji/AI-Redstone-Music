execute if score music_progress nbs_s matches 22080..22320 if score music_progress nbs_t matches ..275 run function minecraft:music/fanwutuobang_demo/notes/276
