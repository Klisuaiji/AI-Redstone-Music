execute if score music_progress nbs_s matches 10240..15520 run function minecraft:music/fanwutuobang_demo/tree/128_191
execute if score music_progress nbs_s matches 15360..20720 run function minecraft:music/fanwutuobang_demo/tree/192_255
