execute if score music_progress nbs_s matches 8960..9760 run function minecraft:music/fanwutuobang_demo/tree/112_119
execute if score music_progress nbs_s matches 9600..10480 run function minecraft:music/fanwutuobang_demo/tree/120_127
