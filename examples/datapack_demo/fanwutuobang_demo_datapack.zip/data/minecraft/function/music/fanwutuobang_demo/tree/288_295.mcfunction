execute if score music_progress nbs_s matches 23040..23520 run function minecraft:music/fanwutuobang_demo/tree/288_291
execute if score music_progress nbs_s matches 23360..23920 run function minecraft:music/fanwutuobang_demo/tree/292_295
