execute if score music_progress nbs_s matches 8960..9280 run function minecraft:music/fanwutuobang_demo/tree/112_113
