execute if score music_progress nbs_s matches 7680..8480 run function minecraft:music/fanwutuobang_demo/tree/96_103
execute if score music_progress nbs_s matches 8320..9200 run function minecraft:music/fanwutuobang_demo/tree/104_111
