execute if score music_progress nbs_s matches 9280..9600 run function minecraft:music/fanwutuobang_demo/tree/116_117
execute if score music_progress nbs_s matches 9440..9840 run function minecraft:music/fanwutuobang_demo/tree/118_119
