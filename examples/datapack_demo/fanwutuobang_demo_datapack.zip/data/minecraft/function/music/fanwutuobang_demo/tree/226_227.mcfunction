execute if score music_progress nbs_s matches 18080..18320 if score music_progress nbs_t matches ..225 run function minecraft:music/fanwutuobang_demo/notes/226
