execute if score music_progress nbs_s matches 13280..13680 run function minecraft:music/fanwutuobang_demo/tree/166_167
