execute if score music_progress nbs_s matches 5280..5520 if score music_progress nbs_t matches ..65 run function minecraft:music/fanwutuobang_demo/notes/66
