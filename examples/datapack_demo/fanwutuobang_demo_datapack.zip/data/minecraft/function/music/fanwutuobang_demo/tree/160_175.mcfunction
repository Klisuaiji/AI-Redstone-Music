execute if score music_progress nbs_s matches 12800..13600 run function minecraft:music/fanwutuobang_demo/tree/160_167
execute if score music_progress nbs_s matches 13440..14320 run function minecraft:music/fanwutuobang_demo/tree/168_175
