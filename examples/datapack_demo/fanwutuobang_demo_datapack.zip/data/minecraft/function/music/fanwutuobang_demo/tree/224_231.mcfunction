execute if score music_progress nbs_s matches 17920..18400 run function minecraft:music/fanwutuobang_demo/tree/224_227
execute if score music_progress nbs_s matches 18240..18800 run function minecraft:music/fanwutuobang_demo/tree/228_231
