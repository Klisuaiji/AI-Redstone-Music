execute if score music_progress nbs_s matches 21120..21600 run function minecraft:music/fanwutuobang_demo/tree/264_267
execute if score music_progress nbs_s matches 21440..22000 run function minecraft:music/fanwutuobang_demo/tree/268_271
