execute if score music_progress nbs_s matches 15680..15920 if score music_progress nbs_t matches ..195 run function minecraft:music/fanwutuobang_demo/notes/196
