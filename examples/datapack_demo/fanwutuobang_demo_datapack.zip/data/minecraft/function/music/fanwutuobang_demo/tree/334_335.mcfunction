execute if score music_progress nbs_s matches 26720..26960 if score music_progress nbs_t matches ..334 run function minecraft:music/fanwutuobang_demo/notes/335
