execute if score music_progress nbs_s matches 21760..22560 run function minecraft:music/fanwutuobang_demo/tree/272_279
execute if score music_progress nbs_s matches 22400..23280 run function minecraft:music/fanwutuobang_demo/tree/280_287
