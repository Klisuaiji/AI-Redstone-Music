execute if score music_progress nbs_s matches 23040..23360 run function minecraft:music/fanwutuobang_demo/tree/288_289
execute if score music_progress nbs_s matches 23200..23600 run function minecraft:music/fanwutuobang_demo/tree/290_291
