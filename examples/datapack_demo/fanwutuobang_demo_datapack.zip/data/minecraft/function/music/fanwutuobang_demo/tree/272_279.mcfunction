execute if score music_progress nbs_s matches 21760..22240 run function minecraft:music/fanwutuobang_demo/tree/272_275
execute if score music_progress nbs_s matches 22080..22640 run function minecraft:music/fanwutuobang_demo/tree/276_279
