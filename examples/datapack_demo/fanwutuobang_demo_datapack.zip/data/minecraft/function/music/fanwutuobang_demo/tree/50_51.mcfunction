execute if score music_progress nbs_s matches 4000..4240 if score music_progress nbs_t matches ..50 run function minecraft:music/fanwutuobang_demo/notes/51
