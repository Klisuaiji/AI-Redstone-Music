execute if score music_progress nbs_s matches 20480..20960 run function minecraft:music/fanwutuobang_demo/tree/256_259
execute if score music_progress nbs_s matches 20800..21360 run function minecraft:music/fanwutuobang_demo/tree/260_263
