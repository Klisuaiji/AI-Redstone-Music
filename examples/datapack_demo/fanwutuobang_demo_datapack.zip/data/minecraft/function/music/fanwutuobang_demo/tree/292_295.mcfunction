execute if score music_progress nbs_s matches 23360..23680 run function minecraft:music/fanwutuobang_demo/tree/292_293
