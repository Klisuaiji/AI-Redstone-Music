execute if score music_progress nbs_s matches 24960..25200 if score music_progress nbs_t matches ..312 run function minecraft:music/fanwutuobang_demo/notes/313
