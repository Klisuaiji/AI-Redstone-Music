execute if score music_progress nbs_s matches 7680..7920 if score music_progress nbs_t matches ..95 run function minecraft:music/fanwutuobang_demo/notes/96
