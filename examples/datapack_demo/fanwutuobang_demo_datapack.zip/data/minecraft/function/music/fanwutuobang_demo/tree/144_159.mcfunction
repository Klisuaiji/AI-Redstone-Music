execute if score music_progress nbs_s matches 11520..12320 run function minecraft:music/fanwutuobang_demo/tree/144_151
execute if score music_progress nbs_s matches 12160..13040 run function minecraft:music/fanwutuobang_demo/tree/152_159
