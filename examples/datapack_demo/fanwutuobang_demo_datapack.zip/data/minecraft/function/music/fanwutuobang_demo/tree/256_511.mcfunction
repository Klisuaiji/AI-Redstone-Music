execute if score music_progress nbs_s matches 20480..30880 run function minecraft:music/fanwutuobang_demo/tree/256_383
