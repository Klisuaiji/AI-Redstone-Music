execute if score music_progress nbs_s matches 7680..8000 run function minecraft:music/fanwutuobang_demo/tree/96_97
execute if score music_progress nbs_s matches 7840..8240 run function minecraft:music/fanwutuobang_demo/tree/98_99
