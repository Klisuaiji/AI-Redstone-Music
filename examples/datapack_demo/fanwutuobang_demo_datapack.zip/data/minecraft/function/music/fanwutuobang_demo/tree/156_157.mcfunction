execute if score music_progress nbs_s matches 12480..12720 if score music_progress nbs_t matches ..155 run function minecraft:music/fanwutuobang_demo/notes/156
