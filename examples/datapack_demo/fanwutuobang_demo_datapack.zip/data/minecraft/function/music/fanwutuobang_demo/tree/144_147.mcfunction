execute if score music_progress nbs_s matches 11680..12080 run function minecraft:music/fanwutuobang_demo/tree/146_147
