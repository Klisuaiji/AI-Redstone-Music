execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.basedrum voice @s ^0 ^ ^ 0.6 1.000000 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 1 0.793701 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.harp voice @s ^0 ^ ^ 1 0.793701 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.hat voice @s ^0 ^ ^ 0.25 1.000000 1
scoreboard players set music_progress nbs_t 201
