execute if score music_progress nbs_s matches 20480..20800 run function minecraft:music/fanwutuobang_demo/tree/256_257
execute if score music_progress nbs_s matches 20640..21040 run function minecraft:music/fanwutuobang_demo/tree/258_259
