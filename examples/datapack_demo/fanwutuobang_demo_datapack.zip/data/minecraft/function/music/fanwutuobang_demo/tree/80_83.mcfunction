execute if score music_progress nbs_s matches 6400..6720 run function minecraft:music/fanwutuobang_demo/tree/80_81
execute if score music_progress nbs_s matches 6560..6960 run function minecraft:music/fanwutuobang_demo/tree/82_83
