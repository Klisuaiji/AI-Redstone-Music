execute if score music_progress nbs_s matches 2880..3120 if score music_progress nbs_t matches ..35 run function minecraft:music/fanwutuobang_demo/notes/36
