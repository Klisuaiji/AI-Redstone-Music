execute if score music_progress nbs_s matches 5760..6080 run function minecraft:music/fanwutuobang_demo/tree/72_73
