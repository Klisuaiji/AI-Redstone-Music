execute if score music_progress nbs_s matches 11680..11920 if score music_progress nbs_t matches ..145 run function minecraft:music/fanwutuobang_demo/notes/146
