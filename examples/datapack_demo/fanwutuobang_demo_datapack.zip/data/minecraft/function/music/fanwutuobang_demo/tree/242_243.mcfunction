execute if score music_progress nbs_s matches 19360..19600 if score music_progress nbs_t matches ..242 run function minecraft:music/fanwutuobang_demo/notes/243
