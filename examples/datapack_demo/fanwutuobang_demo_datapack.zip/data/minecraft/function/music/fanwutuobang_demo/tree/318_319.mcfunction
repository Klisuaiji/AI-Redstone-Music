execute if score music_progress nbs_s matches 25440..25680 if score music_progress nbs_t matches ..318 run function minecraft:music/fanwutuobang_demo/notes/319
