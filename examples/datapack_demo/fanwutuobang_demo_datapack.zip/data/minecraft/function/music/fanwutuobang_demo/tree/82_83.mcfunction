execute if score music_progress nbs_s matches 6560..6800 if score music_progress nbs_t matches ..82 run function minecraft:music/fanwutuobang_demo/notes/83
