execute if score music_progress nbs_s matches 16160..16400 if score music_progress nbs_t matches ..202 run function minecraft:music/fanwutuobang_demo/notes/203
