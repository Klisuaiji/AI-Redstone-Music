execute if score music_progress nbs_s matches 18880..19200 run function minecraft:music/fanwutuobang_demo/tree/236_237
execute if score music_progress nbs_s matches 19040..19440 run function minecraft:music/fanwutuobang_demo/tree/238_239
