execute if score music_progress nbs_s matches 20480..21280 run function minecraft:music/fanwutuobang_demo/tree/256_263
execute if score music_progress nbs_s matches 21120..22000 run function minecraft:music/fanwutuobang_demo/tree/264_271
