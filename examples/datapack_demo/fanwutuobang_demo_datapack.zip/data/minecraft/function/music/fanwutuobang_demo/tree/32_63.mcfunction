execute if score music_progress nbs_s matches 2560..4000 run function minecraft:music/fanwutuobang_demo/tree/32_47
execute if score music_progress nbs_s matches 3840..5360 run function minecraft:music/fanwutuobang_demo/tree/48_63
