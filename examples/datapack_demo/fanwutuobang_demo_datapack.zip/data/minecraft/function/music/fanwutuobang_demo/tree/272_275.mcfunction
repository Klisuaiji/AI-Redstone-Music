execute if score music_progress nbs_s matches 21760..22080 run function minecraft:music/fanwutuobang_demo/tree/272_273
