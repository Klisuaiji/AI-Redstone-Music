execute if score music_progress nbs_s matches 5120..7840 run function minecraft:music/fanwutuobang_demo/tree/64_95
execute if score music_progress nbs_s matches 7680..10480 run function minecraft:music/fanwutuobang_demo/tree/96_127
