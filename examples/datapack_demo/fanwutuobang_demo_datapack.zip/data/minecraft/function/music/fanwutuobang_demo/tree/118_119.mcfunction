execute if score music_progress nbs_s matches 9440..9680 if score music_progress nbs_t matches ..117 run function minecraft:music/fanwutuobang_demo/notes/118
