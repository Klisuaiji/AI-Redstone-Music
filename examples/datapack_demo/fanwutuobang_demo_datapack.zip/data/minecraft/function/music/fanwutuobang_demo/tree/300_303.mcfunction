execute if score music_progress nbs_s matches 24000..24320 run function minecraft:music/fanwutuobang_demo/tree/300_301
