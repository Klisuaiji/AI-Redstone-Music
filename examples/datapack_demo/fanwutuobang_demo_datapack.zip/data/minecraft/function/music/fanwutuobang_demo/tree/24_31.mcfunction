execute if score music_progress nbs_s matches 1920..2400 run function minecraft:music/fanwutuobang_demo/tree/24_27
execute if score music_progress nbs_s matches 2240..2800 run function minecraft:music/fanwutuobang_demo/tree/28_31
