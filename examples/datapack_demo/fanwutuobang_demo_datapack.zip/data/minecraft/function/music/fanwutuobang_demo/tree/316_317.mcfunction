execute if score music_progress nbs_s matches 25280..25520 if score music_progress nbs_t matches ..315 run function minecraft:music/fanwutuobang_demo/notes/316
