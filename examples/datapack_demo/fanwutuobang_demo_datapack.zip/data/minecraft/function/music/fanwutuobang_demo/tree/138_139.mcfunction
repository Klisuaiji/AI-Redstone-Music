execute if score music_progress nbs_s matches 11040..11280 if score music_progress nbs_t matches ..137 run function minecraft:music/fanwutuobang_demo/notes/138
