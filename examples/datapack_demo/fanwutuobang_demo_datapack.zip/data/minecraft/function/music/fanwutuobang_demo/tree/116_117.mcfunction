execute if score music_progress nbs_s matches 9280..9520 if score music_progress nbs_t matches ..115 run function minecraft:music/fanwutuobang_demo/notes/116
