execute if score music_progress nbs_s matches 2240..2560 run function minecraft:music/fanwutuobang_demo/tree/28_29
execute if score music_progress nbs_s matches 2400..2800 run function minecraft:music/fanwutuobang_demo/tree/30_31
