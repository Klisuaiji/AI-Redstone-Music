execute if score music_progress nbs_s matches 10080..10480 run function minecraft:music/fanwutuobang_demo/tree/126_127
