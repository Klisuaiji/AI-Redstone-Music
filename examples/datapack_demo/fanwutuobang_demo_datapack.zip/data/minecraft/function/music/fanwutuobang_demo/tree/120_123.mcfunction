execute if score music_progress nbs_s matches 9600..9920 run function minecraft:music/fanwutuobang_demo/tree/120_121
execute if score music_progress nbs_s matches 9760..10160 run function minecraft:music/fanwutuobang_demo/tree/122_123
