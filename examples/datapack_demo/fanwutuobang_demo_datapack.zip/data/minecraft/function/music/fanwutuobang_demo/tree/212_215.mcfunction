execute if score music_progress nbs_s matches 16960..17280 run function minecraft:music/fanwutuobang_demo/tree/212_213
