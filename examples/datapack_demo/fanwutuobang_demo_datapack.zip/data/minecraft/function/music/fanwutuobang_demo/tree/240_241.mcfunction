execute if score music_progress nbs_s matches 19200..19440 if score music_progress nbs_t matches ..240 run function minecraft:music/fanwutuobang_demo/notes/241
