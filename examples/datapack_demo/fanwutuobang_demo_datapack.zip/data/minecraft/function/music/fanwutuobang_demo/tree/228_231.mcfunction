execute if score music_progress nbs_s matches 18240..18560 run function minecraft:music/fanwutuobang_demo/tree/228_229
execute if score music_progress nbs_s matches 18400..18800 run function minecraft:music/fanwutuobang_demo/tree/230_231
