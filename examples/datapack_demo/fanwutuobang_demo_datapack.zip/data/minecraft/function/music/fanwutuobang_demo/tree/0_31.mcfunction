execute if score music_progress nbs_s matches 0..1440 run function minecraft:music/fanwutuobang_demo/tree/0_15
execute if score music_progress nbs_s matches 1280..2800 run function minecraft:music/fanwutuobang_demo/tree/16_31
