execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.pling voice @s ^0 ^ ^ 1 0.594604 1
function minecraft:music/fanwutuobang_demo/stop
