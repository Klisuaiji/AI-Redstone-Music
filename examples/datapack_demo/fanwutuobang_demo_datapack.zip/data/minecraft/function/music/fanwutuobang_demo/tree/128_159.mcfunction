execute if score music_progress nbs_s matches 10240..11680 run function minecraft:music/fanwutuobang_demo/tree/128_143
execute if score music_progress nbs_s matches 11520..13040 run function minecraft:music/fanwutuobang_demo/tree/144_159
