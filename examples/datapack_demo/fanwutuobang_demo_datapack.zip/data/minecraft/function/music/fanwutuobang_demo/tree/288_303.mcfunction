execute if score music_progress nbs_s matches 23040..23840 run function minecraft:music/fanwutuobang_demo/tree/288_295
execute if score music_progress nbs_s matches 23680..24560 run function minecraft:music/fanwutuobang_demo/tree/296_303
