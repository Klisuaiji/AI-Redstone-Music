execute if score music_progress nbs_s matches 6080..6400 run function minecraft:music/fanwutuobang_demo/tree/76_77
execute if score music_progress nbs_s matches 6240..6640 run function minecraft:music/fanwutuobang_demo/tree/78_79
