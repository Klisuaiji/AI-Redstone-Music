execute if score music_progress nbs_s matches 19840..20320 run function minecraft:music/fanwutuobang_demo/tree/248_251
execute if score music_progress nbs_s matches 20160..20720 run function minecraft:music/fanwutuobang_demo/tree/252_255
