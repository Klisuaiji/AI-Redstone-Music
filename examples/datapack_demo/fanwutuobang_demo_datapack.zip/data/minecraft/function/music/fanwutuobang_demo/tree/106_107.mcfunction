execute if score music_progress nbs_s matches 8480..8720 if score music_progress nbs_t matches ..105 run function minecraft:music/fanwutuobang_demo/notes/106
