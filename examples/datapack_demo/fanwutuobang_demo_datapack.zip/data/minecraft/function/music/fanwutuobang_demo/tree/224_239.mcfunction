execute if score music_progress nbs_s matches 17920..18720 run function minecraft:music/fanwutuobang_demo/tree/224_231
execute if score music_progress nbs_s matches 18560..19440 run function minecraft:music/fanwutuobang_demo/tree/232_239
