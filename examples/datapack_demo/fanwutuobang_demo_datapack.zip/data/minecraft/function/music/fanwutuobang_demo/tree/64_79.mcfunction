execute if score music_progress nbs_s matches 5120..5920 run function minecraft:music/fanwutuobang_demo/tree/64_71
execute if score music_progress nbs_s matches 5760..6640 run function minecraft:music/fanwutuobang_demo/tree/72_79
