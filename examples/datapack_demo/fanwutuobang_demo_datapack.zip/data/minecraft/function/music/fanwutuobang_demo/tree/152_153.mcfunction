execute if score music_progress nbs_s matches 12160..12400 if score music_progress nbs_t matches ..152 run function minecraft:music/fanwutuobang_demo/notes/153
