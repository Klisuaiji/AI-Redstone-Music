execute if score music_progress nbs_s matches 18080..18480 run function minecraft:music/fanwutuobang_demo/tree/226_227
