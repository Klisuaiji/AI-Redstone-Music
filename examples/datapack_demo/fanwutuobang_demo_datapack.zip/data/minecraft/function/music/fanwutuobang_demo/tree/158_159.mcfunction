execute if score music_progress nbs_s matches 12640..12880 if score music_progress nbs_t matches ..157 run function minecraft:music/fanwutuobang_demo/notes/158
