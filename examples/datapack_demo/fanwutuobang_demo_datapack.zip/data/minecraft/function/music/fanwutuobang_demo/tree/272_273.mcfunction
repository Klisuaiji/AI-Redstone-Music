execute if score music_progress nbs_s matches 21760..22000 if score music_progress nbs_t matches ..272 run function minecraft:music/fanwutuobang_demo/notes/273
