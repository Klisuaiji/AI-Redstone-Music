execute if score music_progress nbs_s matches 14880..15280 run function minecraft:music/fanwutuobang_demo/tree/186_187
