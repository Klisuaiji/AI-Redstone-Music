execute if score music_progress nbs_s matches 10400..10640 if score music_progress nbs_t matches ..130 run function minecraft:music/fanwutuobang_demo/notes/131
