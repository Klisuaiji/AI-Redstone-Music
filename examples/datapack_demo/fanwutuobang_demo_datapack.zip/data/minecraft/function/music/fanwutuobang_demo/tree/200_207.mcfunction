execute if score music_progress nbs_s matches 16000..16480 run function minecraft:music/fanwutuobang_demo/tree/200_203
execute if score music_progress nbs_s matches 16320..16880 run function minecraft:music/fanwutuobang_demo/tree/204_207
