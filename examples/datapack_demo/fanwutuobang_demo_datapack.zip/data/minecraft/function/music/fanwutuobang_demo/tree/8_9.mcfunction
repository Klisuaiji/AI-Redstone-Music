execute if score music_progress nbs_s matches 640..880 if score music_progress nbs_t matches ..7 run function minecraft:music/fanwutuobang_demo/notes/8
