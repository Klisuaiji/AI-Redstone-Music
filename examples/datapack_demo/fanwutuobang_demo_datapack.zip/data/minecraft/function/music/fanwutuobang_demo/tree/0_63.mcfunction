execute if score music_progress nbs_s matches 0..2720 run function minecraft:music/fanwutuobang_demo/tree/0_31
execute if score music_progress nbs_s matches 2560..5360 run function minecraft:music/fanwutuobang_demo/tree/32_63
