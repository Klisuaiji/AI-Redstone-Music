execute if score music_progress nbs_s matches 8960..9440 run function minecraft:music/fanwutuobang_demo/tree/112_115
execute if score music_progress nbs_s matches 9280..9840 run function minecraft:music/fanwutuobang_demo/tree/116_119
