execute if score music_progress nbs_s matches 2080..2320 if score music_progress nbs_t matches ..25 run function minecraft:music/fanwutuobang_demo/notes/26
