execute if score music_progress nbs_s matches 8800..9040 if score music_progress nbs_t matches ..110 run function minecraft:music/fanwutuobang_demo/notes/111
