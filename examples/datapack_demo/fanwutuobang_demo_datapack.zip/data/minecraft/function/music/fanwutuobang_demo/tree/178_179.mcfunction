execute if score music_progress nbs_s matches 14240..14480 if score music_progress nbs_t matches ..177 run function minecraft:music/fanwutuobang_demo/notes/178
