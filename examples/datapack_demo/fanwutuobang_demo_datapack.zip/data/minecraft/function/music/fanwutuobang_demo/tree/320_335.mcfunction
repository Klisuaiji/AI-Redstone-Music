execute if score music_progress nbs_s matches 25600..26400 run function minecraft:music/fanwutuobang_demo/tree/320_327
execute if score music_progress nbs_s matches 26240..27120 run function minecraft:music/fanwutuobang_demo/tree/328_335
