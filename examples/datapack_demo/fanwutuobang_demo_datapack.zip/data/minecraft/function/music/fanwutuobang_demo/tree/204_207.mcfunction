execute if score music_progress nbs_s matches 16480..16880 run function minecraft:music/fanwutuobang_demo/tree/206_207
