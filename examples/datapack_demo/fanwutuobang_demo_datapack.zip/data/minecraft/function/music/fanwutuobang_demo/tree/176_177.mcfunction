execute if score music_progress nbs_s matches 14080..14320 if score music_progress nbs_t matches ..175 run function minecraft:music/fanwutuobang_demo/notes/176
