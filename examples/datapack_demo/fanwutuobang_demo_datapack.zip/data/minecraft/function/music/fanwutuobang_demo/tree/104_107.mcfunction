execute if score music_progress nbs_s matches 8480..8880 run function minecraft:music/fanwutuobang_demo/tree/106_107
