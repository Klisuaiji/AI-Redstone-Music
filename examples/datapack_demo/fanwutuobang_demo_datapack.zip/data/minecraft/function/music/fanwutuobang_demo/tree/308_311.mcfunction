execute if score music_progress nbs_s matches 24640..24960 run function minecraft:music/fanwutuobang_demo/tree/308_309
execute if score music_progress nbs_s matches 24800..25200 run function minecraft:music/fanwutuobang_demo/tree/310_311
