execute if score music_progress nbs_s matches 7200..7440 if score music_progress nbs_t matches ..90 run function minecraft:music/fanwutuobang_demo/notes/91
