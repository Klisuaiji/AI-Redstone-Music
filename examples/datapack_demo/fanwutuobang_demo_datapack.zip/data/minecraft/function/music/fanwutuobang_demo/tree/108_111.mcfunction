execute if score music_progress nbs_s matches 8640..8960 run function minecraft:music/fanwutuobang_demo/tree/108_109
execute if score music_progress nbs_s matches 8800..9200 run function minecraft:music/fanwutuobang_demo/tree/110_111
