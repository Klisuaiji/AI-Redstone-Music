execute if score music_progress nbs_s matches 20800..21120 run function minecraft:music/fanwutuobang_demo/tree/260_261
execute if score music_progress nbs_s matches 20960..21360 run function minecraft:music/fanwutuobang_demo/tree/262_263
