execute if score music_progress nbs_s matches 23360..23600 if score music_progress nbs_t matches ..292 run function minecraft:music/fanwutuobang_demo/notes/293
