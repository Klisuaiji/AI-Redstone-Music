execute if score music_progress nbs_s matches 26880..27680 run function minecraft:music/fanwutuobang_demo/tree/336_343
