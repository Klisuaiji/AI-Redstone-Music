execute if score music_progress nbs_s matches 24640..24880 if score music_progress nbs_t matches ..307 run function minecraft:music/fanwutuobang_demo/notes/308
