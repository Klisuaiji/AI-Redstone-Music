execute if score music_progress nbs_s matches 15360..15840 run function minecraft:music/fanwutuobang_demo/tree/192_195
execute if score music_progress nbs_s matches 15680..16240 run function minecraft:music/fanwutuobang_demo/tree/196_199
