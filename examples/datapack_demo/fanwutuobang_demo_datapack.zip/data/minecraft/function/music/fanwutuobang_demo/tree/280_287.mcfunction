execute if score music_progress nbs_s matches 22400..22880 run function minecraft:music/fanwutuobang_demo/tree/280_283
execute if score music_progress nbs_s matches 22720..23280 run function minecraft:music/fanwutuobang_demo/tree/284_287
