execute if score music_progress nbs_s matches 12000..12240 if score music_progress nbs_t matches ..150 run function minecraft:music/fanwutuobang_demo/notes/151
