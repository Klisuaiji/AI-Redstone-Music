execute if score music_progress nbs_s matches 12800..14240 run function minecraft:music/fanwutuobang_demo/tree/160_175
execute if score music_progress nbs_s matches 14080..15600 run function minecraft:music/fanwutuobang_demo/tree/176_191
