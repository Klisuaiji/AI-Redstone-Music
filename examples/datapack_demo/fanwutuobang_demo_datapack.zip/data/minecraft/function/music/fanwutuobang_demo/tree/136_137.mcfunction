execute if score music_progress nbs_s matches 10880..11120 if score music_progress nbs_t matches ..135 run function minecraft:music/fanwutuobang_demo/notes/136
