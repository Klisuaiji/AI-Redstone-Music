execute if score music_progress nbs_s matches 14080..14400 run function minecraft:music/fanwutuobang_demo/tree/176_177
execute if score music_progress nbs_s matches 14240..14640 run function minecraft:music/fanwutuobang_demo/tree/178_179
