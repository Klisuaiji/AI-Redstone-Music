execute if score music_progress nbs_s matches 5600..5840 if score music_progress nbs_t matches ..70 run function minecraft:music/fanwutuobang_demo/notes/71
