execute if score music_progress nbs_s matches 7040..7520 run function minecraft:music/fanwutuobang_demo/tree/88_91
