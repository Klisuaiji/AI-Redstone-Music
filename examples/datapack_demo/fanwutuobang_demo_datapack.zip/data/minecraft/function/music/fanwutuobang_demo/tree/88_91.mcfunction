execute if score music_progress nbs_s matches 7040..7360 run function minecraft:music/fanwutuobang_demo/tree/88_89
execute if score music_progress nbs_s matches 7200..7600 run function minecraft:music/fanwutuobang_demo/tree/90_91
