execute if score music_progress nbs_s matches 23040..24480 run function minecraft:music/fanwutuobang_demo/tree/288_303
execute if score music_progress nbs_s matches 24320..25840 run function minecraft:music/fanwutuobang_demo/tree/304_319
