execute if score music_progress nbs_s matches 0..800 run function minecraft:music/fanwutuobang_demo/tree/0_7
execute if score music_progress nbs_s matches 640..1520 run function minecraft:music/fanwutuobang_demo/tree/8_15
