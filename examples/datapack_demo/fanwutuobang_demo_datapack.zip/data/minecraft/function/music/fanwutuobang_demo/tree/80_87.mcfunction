execute if score music_progress nbs_s matches 6400..6880 run function minecraft:music/fanwutuobang_demo/tree/80_83
execute if score music_progress nbs_s matches 6720..7280 run function minecraft:music/fanwutuobang_demo/tree/84_87
