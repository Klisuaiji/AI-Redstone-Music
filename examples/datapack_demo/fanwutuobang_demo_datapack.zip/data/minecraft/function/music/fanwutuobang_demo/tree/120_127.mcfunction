execute if score music_progress nbs_s matches 9600..10080 run function minecraft:music/fanwutuobang_demo/tree/120_123
execute if score music_progress nbs_s matches 9920..10480 run function minecraft:music/fanwutuobang_demo/tree/124_127
