execute if score music_progress nbs_s matches 3680..3920 if score music_progress nbs_t matches ..45 run function minecraft:music/fanwutuobang_demo/notes/46
