execute if score music_progress nbs_s matches 18560..19040 run function minecraft:music/fanwutuobang_demo/tree/232_235
execute if score music_progress nbs_s matches 18880..19440 run function minecraft:music/fanwutuobang_demo/tree/236_239
