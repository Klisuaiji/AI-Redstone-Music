execute if score music_progress nbs_s matches 800..1040 if score music_progress nbs_t matches ..10 run function minecraft:music/fanwutuobang_demo/notes/11
