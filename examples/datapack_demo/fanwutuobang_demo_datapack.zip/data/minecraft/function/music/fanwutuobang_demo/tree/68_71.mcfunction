execute if score music_progress nbs_s matches 5440..5760 run function minecraft:music/fanwutuobang_demo/tree/68_69
execute if score music_progress nbs_s matches 5600..6000 run function minecraft:music/fanwutuobang_demo/tree/70_71
