execute if score music_progress nbs_s matches 1280..2080 run function minecraft:music/fanwutuobang_demo/tree/16_23
execute if score music_progress nbs_s matches 1920..2800 run function minecraft:music/fanwutuobang_demo/tree/24_31
