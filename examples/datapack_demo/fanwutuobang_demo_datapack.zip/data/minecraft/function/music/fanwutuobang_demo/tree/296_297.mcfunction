execute if score music_progress nbs_s matches 23680..23920 if score music_progress nbs_t matches ..295 run function minecraft:music/fanwutuobang_demo/notes/296
