execute if score music_progress nbs_s matches 480..720 if score music_progress nbs_t matches ..5 run function minecraft:music/fanwutuobang_demo/notes/6
