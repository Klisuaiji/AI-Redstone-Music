execute if score music_progress nbs_s matches 10880..11360 run function minecraft:music/fanwutuobang_demo/tree/136_139
execute if score music_progress nbs_s matches 11200..11760 run function minecraft:music/fanwutuobang_demo/tree/140_143
