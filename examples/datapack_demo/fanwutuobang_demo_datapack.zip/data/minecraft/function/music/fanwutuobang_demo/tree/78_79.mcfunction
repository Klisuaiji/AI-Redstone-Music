execute if score music_progress nbs_s matches 6240..6480 if score music_progress nbs_t matches ..77 run function minecraft:music/fanwutuobang_demo/notes/78
