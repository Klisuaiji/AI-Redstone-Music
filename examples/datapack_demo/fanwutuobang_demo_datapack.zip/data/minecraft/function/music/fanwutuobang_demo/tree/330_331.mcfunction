execute if score music_progress nbs_s matches 26400..26640 if score music_progress nbs_t matches ..329 run function minecraft:music/fanwutuobang_demo/notes/330
