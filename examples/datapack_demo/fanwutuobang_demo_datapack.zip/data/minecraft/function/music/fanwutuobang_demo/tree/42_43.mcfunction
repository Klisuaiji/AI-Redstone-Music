execute if score music_progress nbs_s matches 3360..3600 if score music_progress nbs_t matches ..42 run function minecraft:music/fanwutuobang_demo/notes/43
