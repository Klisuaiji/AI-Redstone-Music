execute if score music_progress nbs_s matches 24960..25280 run function minecraft:music/fanwutuobang_demo/tree/312_313
