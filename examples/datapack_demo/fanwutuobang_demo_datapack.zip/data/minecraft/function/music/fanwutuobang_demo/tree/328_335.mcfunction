execute if score music_progress nbs_s matches 26240..26720 run function minecraft:music/fanwutuobang_demo/tree/328_331
execute if score music_progress nbs_s matches 26560..27120 run function minecraft:music/fanwutuobang_demo/tree/332_335
