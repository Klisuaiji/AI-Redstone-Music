execute if score music_progress nbs_s matches 15360..15680 run function minecraft:music/fanwutuobang_demo/tree/192_193
