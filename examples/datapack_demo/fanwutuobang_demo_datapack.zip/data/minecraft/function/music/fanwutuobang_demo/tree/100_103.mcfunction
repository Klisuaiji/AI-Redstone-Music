execute if score music_progress nbs_s matches 8000..8320 run function minecraft:music/fanwutuobang_demo/tree/100_101
