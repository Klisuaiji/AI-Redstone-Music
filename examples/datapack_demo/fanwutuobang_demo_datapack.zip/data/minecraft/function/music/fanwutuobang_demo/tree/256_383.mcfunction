execute if score music_progress nbs_s matches 20480..25760 run function minecraft:music/fanwutuobang_demo/tree/256_319
execute if score music_progress nbs_s matches 25600..30960 run function minecraft:music/fanwutuobang_demo/tree/320_383
