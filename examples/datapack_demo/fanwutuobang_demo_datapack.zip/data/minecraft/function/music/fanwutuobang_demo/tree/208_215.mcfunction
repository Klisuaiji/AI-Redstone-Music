execute if score music_progress nbs_s matches 16640..17120 run function minecraft:music/fanwutuobang_demo/tree/208_211
execute if score music_progress nbs_s matches 16960..17520 run function minecraft:music/fanwutuobang_demo/tree/212_215
