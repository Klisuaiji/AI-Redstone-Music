execute if score music_progress nbs_s matches 10240..11040 run function minecraft:music/fanwutuobang_demo/tree/128_135
execute if score music_progress nbs_s matches 10880..11760 run function minecraft:music/fanwutuobang_demo/tree/136_143
