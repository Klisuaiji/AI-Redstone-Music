execute if score music_progress nbs_s matches 12800..13040 if score music_progress nbs_t matches ..160 run function minecraft:music/fanwutuobang_demo/notes/161
