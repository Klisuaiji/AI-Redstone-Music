execute if score music_progress music_type matches 16 run scoreboard players operation music_progress nbs_s += #speed nbs_s
execute if score music_progress music_type matches 16 run function minecraft:music/fanwutuobang_demo/tree/0_511
