execute if score music_progress nbs_s matches 20800..21040 if score music_progress nbs_t matches ..260 run function minecraft:music/fanwutuobang_demo/notes/261
