execute if score music_progress nbs_s matches 27200..27520 run function minecraft:music/fanwutuobang_demo/tree/340_341
