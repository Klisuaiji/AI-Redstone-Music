execute if score music_progress nbs_s matches 15360..18080 run function minecraft:music/fanwutuobang_demo/tree/192_223
execute if score music_progress nbs_s matches 17920..20720 run function minecraft:music/fanwutuobang_demo/tree/224_255
