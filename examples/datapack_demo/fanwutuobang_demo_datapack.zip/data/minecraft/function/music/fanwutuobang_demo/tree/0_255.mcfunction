execute if score music_progress nbs_s matches 0..10400 run function minecraft:music/fanwutuobang_demo/tree/0_127
execute if score music_progress nbs_s matches 10240..20720 run function minecraft:music/fanwutuobang_demo/tree/128_255
