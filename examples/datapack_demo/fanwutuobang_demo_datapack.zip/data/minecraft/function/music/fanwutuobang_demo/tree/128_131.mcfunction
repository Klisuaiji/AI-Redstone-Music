execute if score music_progress nbs_s matches 10240..10560 run function minecraft:music/fanwutuobang_demo/tree/128_129
execute if score music_progress nbs_s matches 10400..10800 run function minecraft:music/fanwutuobang_demo/tree/130_131
