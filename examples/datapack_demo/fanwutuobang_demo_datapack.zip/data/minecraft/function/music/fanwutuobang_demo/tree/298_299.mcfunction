execute if score music_progress nbs_s matches 23840..24080 if score music_progress nbs_t matches ..297 run function minecraft:music/fanwutuobang_demo/notes/298
