execute if score music_progress nbs_s matches 3200..3440 if score music_progress nbs_t matches ..40 run function minecraft:music/fanwutuobang_demo/notes/41
