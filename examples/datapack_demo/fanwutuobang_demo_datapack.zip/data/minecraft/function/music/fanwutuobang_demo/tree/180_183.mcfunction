execute if score music_progress nbs_s matches 14400..14720 run function minecraft:music/fanwutuobang_demo/tree/180_181
