execute if score music_progress nbs_s matches 5760..6000 if score music_progress nbs_t matches ..72 run function minecraft:music/fanwutuobang_demo/notes/73
