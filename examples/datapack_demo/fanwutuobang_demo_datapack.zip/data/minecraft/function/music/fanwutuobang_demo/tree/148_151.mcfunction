execute if score music_progress nbs_s matches 12000..12400 run function minecraft:music/fanwutuobang_demo/tree/150_151
