execute if score music_progress nbs_s matches 20480..23200 run function minecraft:music/fanwutuobang_demo/tree/256_287
execute if score music_progress nbs_s matches 23040..25840 run function minecraft:music/fanwutuobang_demo/tree/288_319
