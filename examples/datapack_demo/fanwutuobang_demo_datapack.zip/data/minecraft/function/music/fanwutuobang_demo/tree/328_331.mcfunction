execute if score music_progress nbs_s matches 26400..26800 run function minecraft:music/fanwutuobang_demo/tree/330_331
