execute if score music_progress nbs_s matches 14080..14880 run function minecraft:music/fanwutuobang_demo/tree/176_183
execute if score music_progress nbs_s matches 14720..15600 run function minecraft:music/fanwutuobang_demo/tree/184_191
