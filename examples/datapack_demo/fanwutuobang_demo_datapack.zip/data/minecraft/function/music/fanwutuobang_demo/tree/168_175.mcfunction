execute if score music_progress nbs_s matches 13440..13920 run function minecraft:music/fanwutuobang_demo/tree/168_171
