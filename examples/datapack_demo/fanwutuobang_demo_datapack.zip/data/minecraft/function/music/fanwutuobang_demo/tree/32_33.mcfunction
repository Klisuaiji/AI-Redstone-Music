execute if score music_progress nbs_s matches 2560..2800 if score music_progress nbs_t matches ..32 run function minecraft:music/fanwutuobang_demo/notes/33
