execute if score music_progress nbs_s matches 20960..21200 if score music_progress nbs_t matches ..262 run function minecraft:music/fanwutuobang_demo/notes/263
