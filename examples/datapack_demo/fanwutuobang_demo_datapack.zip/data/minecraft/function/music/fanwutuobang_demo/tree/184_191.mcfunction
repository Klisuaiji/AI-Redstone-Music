execute if score music_progress nbs_s matches 14720..15200 run function minecraft:music/fanwutuobang_demo/tree/184_187
execute if score music_progress nbs_s matches 15040..15600 run function minecraft:music/fanwutuobang_demo/tree/188_191
