execute if score music_progress nbs_s matches 21280..21520 if score music_progress nbs_t matches ..265 run function minecraft:music/fanwutuobang_demo/notes/266
