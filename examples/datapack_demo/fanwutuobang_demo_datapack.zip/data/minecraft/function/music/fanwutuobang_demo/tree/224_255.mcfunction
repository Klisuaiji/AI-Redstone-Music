execute if score music_progress nbs_s matches 17920..19360 run function minecraft:music/fanwutuobang_demo/tree/224_239
execute if score music_progress nbs_s matches 19200..20720 run function minecraft:music/fanwutuobang_demo/tree/240_255
