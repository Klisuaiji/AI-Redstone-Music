execute if score music_progress nbs_s matches 2880..3200 run function minecraft:music/fanwutuobang_demo/tree/36_37
execute if score music_progress nbs_s matches 3040..3440 run function minecraft:music/fanwutuobang_demo/tree/38_39
