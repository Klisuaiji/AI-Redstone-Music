execute if score music_progress nbs_s matches 0..240 if score music_progress nbs_t matches ..0 run function minecraft:music/fanwutuobang_demo/notes/1
