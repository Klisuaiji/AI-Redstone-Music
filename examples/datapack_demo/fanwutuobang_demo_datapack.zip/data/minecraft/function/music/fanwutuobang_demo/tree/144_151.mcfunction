execute if score music_progress nbs_s matches 11520..12000 run function minecraft:music/fanwutuobang_demo/tree/144_147
execute if score music_progress nbs_s matches 11840..12400 run function minecraft:music/fanwutuobang_demo/tree/148_151
