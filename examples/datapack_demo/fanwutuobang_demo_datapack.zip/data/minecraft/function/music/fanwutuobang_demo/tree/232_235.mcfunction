execute if score music_progress nbs_s matches 18560..18880 run function minecraft:music/fanwutuobang_demo/tree/232_233
