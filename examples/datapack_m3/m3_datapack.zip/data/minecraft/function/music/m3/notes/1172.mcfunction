execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.bass voice @s ^0 ^ ^ 1 0.840896 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.basedrum voice @s ^0 ^ ^ 0.6 0.500000 1
scoreboard players set music_progress nbs_t 1172
