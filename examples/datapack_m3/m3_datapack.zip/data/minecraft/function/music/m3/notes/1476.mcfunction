execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 1 1.887749 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.bass voice @s ^0 ^ ^ 1 1.122462 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.hat voice @s ^0 ^ ^ 0.25 0.500000 1
scoreboard players set music_progress nbs_t 1476
