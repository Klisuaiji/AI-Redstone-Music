execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.flute voice @s ^0 ^ ^ 1 0.749154 1
scoreboard players set music_progress nbs_t 1045
