execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.bass voice @s ^0 ^ ^ 1 0.840896 1
scoreboard players set music_progress nbs_t 2325
