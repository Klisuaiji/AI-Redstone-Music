execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.bass voice @s ^0 ^ ^ 1 0.561231 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.basedrum voice @s ^0 ^ ^ 0.6 0.500000 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.snare voice @s ^0 ^ ^ 0.5 0.500000 1
scoreboard players set music_progress nbs_t 2022
