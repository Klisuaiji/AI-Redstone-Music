execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.flute voice @s ^0 ^ ^ 1 1.414214 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 1 0.500000 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 1 0.749154 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.basedrum voice @s ^0 ^ ^ 0.6 0.500000 1
scoreboard players set music_progress nbs_t 1065
