execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.flute voice @s ^0 ^ ^ 1 0.943874 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 1 1.498307 1
scoreboard players set music_progress nbs_t 168
