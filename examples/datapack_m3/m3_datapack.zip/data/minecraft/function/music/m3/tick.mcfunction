execute if score music_progress music_type matches 9 run scoreboard players operation music_progress nbs_s += #speed nbs_s
execute if score music_progress music_type matches 9 run function minecraft:music/m3/tree/0_4095
