﻿================ M3 红石音乐数据包 (MC 26.2) ================
源文件: M3-LesApollo2wiOxP_2.mid   144 BPM   4/4   时长 165.8 秒
数据包格式: 107.1 (Java 版 26.2)
播放路径: minecraft:music/m3   song_id = 9   #speed nbs_s = 80 (note tick = 游戏 tick)

【安装】
1. 把 m3-redstone-music-26.2.zip 放进存档的 datapacks/ 文件夹
   (或把解压后的 m3-redstone-music-26.2 文件夹放进去)
2. 进游戏执行 /reload
3. /function minecraft:music/m3/play   开始播放
   /function minecraft:music/m3/stop   停止
   给自己打上 no_music 标签 = 本曲静音 (不影响其他玩家)

【挂到已有的 lemon 系音乐数据包】
  删除 pack.mcmeta、data/minecraft/tags/function/{load,tick}.json,
  把 data/minecraft/function/music/m3/ 整个文件夹放进宿主包,
  确认宿主每刻执行 minecraft:music/m3/tick、init 里有 #speed nbs_s = 80,
  并把 song_id 9 改成宿主内未占用的编号 (play/stop/tick 共 3 处)。

【编曲】
  MIDI distorted electric guitar (>=72) -> flute  主旋律   vol 1.0
  MIDI distorted electric guitar (<=70) -> guitar 和弦伴奏 vol 1.0
  MIDI electric bass                   -> bass   贝斯     vol 1.0
  MIDI drums: GM36 -> basedrum 0.6 | GM38/40 -> snare 0.5 | 其余 -> hat 0.25
  生成工具: Klisuaiji/RedstoneMusic-Skill 的 generate.py (叶子节点修复版)
