function minecraft:music/box/tick
function minecraft:music/box/lrc_tick
function minecraft:music/box/dim_check
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/flower_dance_main_loop

#分数

#execute as @a[team=parkour] at @s run function minecraft:music/main_loop
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/kagec3/tick
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/sanyaose/tick
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/touhoukami/tick
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/lemon/tick
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/after_the_rain/tick
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/baka/tick
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/badapple/tick
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/lunatic/tick
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/popcorn/tick
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/un/tick
execute unless score #mb_pause mb_cfg matches 1 unless score #dim_any mb_cfg matches 1 run function minecraft:music/shanghaitea/tick
#execute as @a[team=!lobby,team=!parkour] run scoreboard players set music_progress music_type 1
#execute as @a[team=!lobby,team=!parkour] run scoreboard players set @s time -20
