================ 红石音乐盒 v2（合并完善版） ================
兼容版本：1.21.2-1.21.3 / 1.21.4 / 1.21.5 / 1.21.6-1.21.8 / 26.2 / 26.2
（pack_format 57-107.1）

【安装】
1. 将本 zip 直接放入存档的 datapacks 文件夹（.minecraft/saves/<存档>/datapacks/）
2. 进入世界后 /reload
3. 聊天栏提示「已成功加载音乐数据包」后，输入 /trigger menu 领取附魔唱片机

【操作】
- /trigger menu            领取/再领 红石音乐盒（附魔唱片机，不可放置不可丢弃）
- 手持唱片机：
    左键单击    上一首
    左键长按    暂停/继续
    右键单击    下一首
    右键双击    打开/关闭点歌菜单
   （丢弃会自动补发，掉落物自动清理；再输一次 /trigger menu 也可再领）
- /trigger lyc             歌词显示开/关（第17首《After the Rain》含43句歌词，字幕随音乐切换）
- 点歌：
    /trigger song set 0-10    按编号点歌
    /trigger mb_歌名 set 1    每首歌专属 trigger
- 删除唱片机：/function minecraft:music/box/remove
- 维度禁播：
    /function minecraft:music/box/dim_ban     禁播执行者所在维度
    /function minecraft:music/box/dim_unban   解除禁播
    /function minecraft:music/box/dim_status  查看禁播名单
    /function minecraft:music/box/ban_enable  启用禁播（默认）
    /function minecraft:music/box/ban_disable 关闭禁播

【曲目库】11 首
编号0 kagec3 | 1 sanyaose | 2 touhoukami | 3 lemon | 4 After the Rain(雨停时分)
5 baka | 6 badapple | 7 lunatic | 8 popcorn | 9 UN | 10 shanghaitea
编号即 /trigger song set 的取值；music_type=17 为《雨停时分》。
原播放链 lemon -> After the Rain -> baka 已保留，切歌/暂停/恢复均原生联动。
