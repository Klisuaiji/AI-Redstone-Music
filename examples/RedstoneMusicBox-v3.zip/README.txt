================ 红石音乐盒 v3 ================
兼容版本：1.21.2-1.21.3 / 1.21.4 / 1.21.5 / 1.21.6-1.21.8 / 26.2
（pack_format 57-107.1）

【安装】
1. 将本 zip 直接放入存档的 datapacks 文件夹（.minecraft/saves/<存档>/datapacks/）
2. 进入世界后 /reload
3. 聊天栏提示「已成功加载音乐数据包」后，输入 /trigger redstonemusic:menu 领取附魔唱片机

【操作】
- /trigger redstonemusic:menu   领取红石音乐盒（附魔唱片机，不可放置不可丢弃）
                                再输一次可收回背包中的唱片机，再输一次又会重新发放
- /trigger lrc                  歌词显示开/关（《反乌托邦》与《雨停时分》支持歌词）
- /trigger play set 编号        点歌（编号见下方曲目库）
- /trigger mb_歌名 set 1        每首歌专属 trigger
- 手持唱片机：左键单击 上一首 | 左键长按 暂停/继续 | 右键单击 下一首 | 右键双击 点歌菜单
  （丢弃会自动补发，掉落物自动清理）

【曲目库】12 首
编号0 kagec3 | 1 sanyaose | 2 touhoukami | 3 lemon | 4 After the Rain(雨停时分)
5 baka | 6 badapple | 7 lunatic | 8 popcorn | 9 UN | 10 shanghaitea | 11 反乌托邦

《反乌托邦》(乌托邦P)：伴奏/鼓组完全同步 MIDI 音源，人声 pling 主旋律，/trigger lrc 开启后
副标题逐句显示歌词（源自官方 LRC，49 句）。

【维度禁播】
/function minecraft:music/box/dim_ban     禁播执行者所在维度
/function minecraft:music/box/dim_unban   解除禁播
/function minecraft:music/box/dim_status  查看禁播名单
/function minecraft:music/box/ban_enable  启用禁播（默认）
/function minecraft:music/box/ban_disable 关闭禁播

【删除唱片机】/function minecraft:music/box/remove