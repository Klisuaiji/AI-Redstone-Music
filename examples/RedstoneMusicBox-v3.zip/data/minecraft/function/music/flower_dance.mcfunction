
execute if score music_progress time matches 1 run function minecraft:tone/3-
execute if score music_progress time matches 1 run function minecraft:tone/-4

execute if score music_progress time matches 9 run function minecraft:tone/2-
execute if score music_progress time matches 9 run function minecraft:tone/1

execute if score music_progress time matches 17 run function minecraft:tone/6-
execute if score music_progress time matches 17 run function minecraft:tone/4

execute if score music_progress time matches 25 run function minecraft:tone/2-
execute if score music_progress time matches 25 run function minecraft:tone/5

execute if score music_progress time matches 33 run function minecraft:tone/3-
execute if score music_progress time matches 33 run function minecraft:tone/6

execute if score music_progress time matches 41 run function minecraft:tone/2-

execute if score music_progress time matches 49 run function minecraft:tone/6

execute if score music_progress time matches 57 run function minecraft:tone/2-

execute if score music_progress time matches 65 run function minecraft:tone/3-
execute if score music_progress time matches 65 run function minecraft:tone/-5

execute if score music_progress time matches 73 run function minecraft:tone/2-
execute if score music_progress time matches 73 run function minecraft:tone/2

execute if score music_progress time matches 81 run function minecraft:tone/6-
execute if score music_progress time matches 81 run function minecraft:tone/5

execute if score music_progress time matches 89 run function minecraft:tone/2-
execute if score music_progress time matches 89 run function minecraft:tone/6

execute if score music_progress time matches 97 run function minecraft:tone/3-
execute if score music_progress time matches 97 run function minecraft:tone/7

execute if score music_progress time matches 105 run function minecraft:tone/2-

execute if score music_progress time matches 113 run function minecraft:tone/6

execute if score music_progress time matches 121 run function minecraft:tone/2-

execute if score music_progress time matches 129 run function minecraft:tone/3-
execute if score music_progress time matches 129 run function minecraft:tone/-6

execute if score music_progress time matches 137 run function minecraft:tone/2-
execute if score music_progress time matches 137 run function minecraft:tone/3

execute if score music_progress time matches 145 run function minecraft:tone/6-
execute if score music_progress time matches 145 run function minecraft:tone/6

execute if score music_progress time matches 153 run function minecraft:tone/2-
execute if score music_progress time matches 153 run function minecraft:tone/7

execute if score music_progress time matches 161 run function minecraft:tone/3-
execute if score music_progress time matches 161 run function minecraft:tone/1-

execute if score music_progress time matches 169 run function minecraft:tone/2-

execute if score music_progress time matches 177 run function minecraft:tone/6

execute if score music_progress time matches 185 run function minecraft:tone/2-

execute if score music_progress time matches 193 run function minecraft:tone/3-

execute if score music_progress time matches 201 run function minecraft:tone/2-

execute if score music_progress time matches 209 run function minecraft:tone/6-

execute if score music_progress time matches 217 run function minecraft:tone/2-

execute if score music_progress time matches 225 run function minecraft:tone/3-

execute if score music_progress time matches 233 run function minecraft:tone/2-

execute if score music_progress time matches 241 run function minecraft:tone/6

execute if score music_progress time matches 249 run function minecraft:tone/2-

execute if score music_progress time matches 257 run function minecraft:tone/3-
execute if score music_progress time matches 257 run function minecraft:tone/-4

execute if score music_progress time matches 265 run function minecraft:tone/2-
execute if score music_progress time matches 265 run function minecraft:tone/1

execute if score music_progress time matches 273 run function minecraft:tone/6-
execute if score music_progress time matches 273 run function minecraft:tone/4

execute if score music_progress time matches 281 run function minecraft:tone/2-
execute if score music_progress time matches 281 run function minecraft:tone/5

execute if score music_progress time matches 289 run function minecraft:tone/3-
execute if score music_progress time matches 289 run function minecraft:tone/6

execute if score music_progress time matches 297 run function minecraft:tone/2-

execute if score music_progress time matches 305 run function minecraft:tone/6

execute if score music_progress time matches 313 run function minecraft:tone/2-

execute if score music_progress time matches 321 run function minecraft:tone/3-
execute if score music_progress time matches 321 run function minecraft:tone/-5

execute if score music_progress time matches 329 run function minecraft:tone/2-
execute if score music_progress time matches 329 run function minecraft:tone/2

execute if score music_progress time matches 337 run function minecraft:tone/6-
execute if score music_progress time matches 337 run function minecraft:tone/5

execute if score music_progress time matches 345 run function minecraft:tone/2-
execute if score music_progress time matches 345 run function minecraft:tone/6

execute if score music_progress time matches 353 run function minecraft:tone/3-
execute if score music_progress time matches 353 run function minecraft:tone/7

execute if score music_progress time matches 361 run function minecraft:tone/2-

execute if score music_progress time matches 369 run function minecraft:tone/6

execute if score music_progress time matches 377 run function minecraft:tone/2-

execute if score music_progress time matches 385 run function minecraft:tone/3-
execute if score music_progress time matches 385 run function minecraft:tone/-6

execute if score music_progress time matches 393 run function minecraft:tone/2-
execute if score music_progress time matches 393 run function minecraft:tone/3

execute if score music_progress time matches 401 run function minecraft:tone/6-
execute if score music_progress time matches 401 run function minecraft:tone/6

execute if score music_progress time matches 409 run function minecraft:tone/2-
execute if score music_progress time matches 409 run function minecraft:tone/7

execute if score music_progress time matches 417 run function minecraft:tone/3-
execute if score music_progress time matches 417 run function minecraft:tone/1-

execute if score music_progress time matches 425 run function minecraft:tone/2-

execute if score music_progress time matches 433 run function minecraft:tone/6

execute if score music_progress time matches 441 run function minecraft:tone/2-

execute if score music_progress time matches 449 run function minecraft:tone/3--
execute if score music_progress time matches 449 run function minecraft:tone/1.5--
execute if score music_progress time matches 449 run function minecraft:tone/6-
execute if score music_progress time matches 449 run function minecraft:tone/3-
execute if score music_progress time matches 449 run function minecraft:tone/6
execute if score music_progress time matches 449 run function minecraft:tone/3
execute if score music_progress time matches 449 run function minecraft:tone/-6


execute if score music_progress time matches 513 run function minecraft:tone/3-

execute if score music_progress time matches 519 run function minecraft:tone/1

execute if score music_progress time matches 528 run function minecraft:tone/6

execute if score music_progress time matches 531 run function minecraft:tone/1-

execute if score music_progress time matches 534 run function minecraft:tone/3-

execute if score music_progress time matches 537 run function minecraft:tone/2-
execute if score music_progress time matches 537 run function minecraft:tone/7
execute if score music_progress time matches 537 run function minecraft:tone/5
execute if score music_progress time matches 537 run function minecraft:tone/-5

execute if score music_progress time matches 543 run function minecraft:tone/2

execute if score music_progress time matches 549 run function minecraft:tone/5-
execute if score music_progress time matches 549 run function minecraft:tone/2-
execute if score music_progress time matches 549 run function minecraft:tone/7
execute if score music_progress time matches 549 run function minecraft:tone/5

execute if score music_progress time matches 561 run function minecraft:tone/2-
execute if score music_progress time matches 561 run function minecraft:tone/7
execute if score music_progress time matches 561 run function minecraft:tone/-3

execute if score music_progress time matches 567 run function minecraft:tone/-7

execute if score music_progress time matches 570 run function minecraft:tone/7-

execute if score music_progress time matches 573 run function minecraft:tone/6-
execute if score music_progress time matches 573 run function minecraft:tone/3

execute if score music_progress time matches 579 run function minecraft:tone/5.5

execute if score music_progress time matches 582 run function minecraft:tone/5.5-

execute if score music_progress time matches 585 run function minecraft:tone/6-
execute if score music_progress time matches 585 run function minecraft:tone/3-
execute if score music_progress time matches 585 run function minecraft:tone/-6

execute if score music_progress time matches 591 run function minecraft:tone/3

execute if score music_progress time matches 597 run function minecraft:tone/3--
execute if score music_progress time matches 597 run function minecraft:tone/6

execute if score music_progress time matches 603 run function minecraft:tone/3

execute if score music_progress time matches 609 run function minecraft:tone/6-
execute if score music_progress time matches 609 run function minecraft:tone/3-
execute if score music_progress time matches 609 run function minecraft:tone/-4

execute if score music_progress time matches 615 run function minecraft:tone/1

execute if score music_progress time matches 621 run function minecraft:tone/3--
execute if score music_progress time matches 621 run function minecraft:tone/6-
execute if score music_progress time matches 621 run function minecraft:tone/4

execute if score music_progress time matches 627 run function minecraft:tone/1

execute if score music_progress time matches 633 run function minecraft:tone/2--
execute if score music_progress time matches 633 run function minecraft:tone/-5

execute if score music_progress time matches 639 run function minecraft:tone/2--
execute if score music_progress time matches 639 run function minecraft:tone/2

execute if score music_progress time matches 641 run function minecraft:tone/3--

execute if score music_progress time matches 643 run function minecraft:tone/2--

execute if score music_progress time matches 645 run function minecraft:tone/7-
execute if score music_progress time matches 645 run function minecraft:tone/5

execute if score music_progress time matches 651 run function minecraft:tone/5-
execute if score music_progress time matches 651 run function minecraft:tone/2

execute if score music_progress time matches 657 run function minecraft:tone/6-
execute if score music_progress time matches 657 run function minecraft:tone/-6

execute if score music_progress time matches 663 run function minecraft:tone/3

execute if score music_progress time matches 669 run function minecraft:tone/6

execute if score music_progress time matches 675 run function minecraft:tone/7

execute if score music_progress time matches 681 run function minecraft:tone/1-

execute if score music_progress time matches 687 run function minecraft:tone/3

execute if score music_progress time matches 693 run function minecraft:tone/6

execute if score music_progress time matches 699 run function minecraft:tone/3-

execute if score music_progress time matches 705 run function minecraft:tone/3-
execute if score music_progress time matches 705 run function minecraft:tone/1-
execute if score music_progress time matches 705 run function minecraft:tone/6
execute if score music_progress time matches 705 run function minecraft:tone/-4

execute if score music_progress time matches 711 run function minecraft:tone/1

execute if score music_progress time matches 720 run function minecraft:tone/6

execute if score music_progress time matches 723 run function minecraft:tone/1-

execute if score music_progress time matches 726 run function minecraft:tone/3-

execute if score music_progress time matches 729 run function minecraft:tone/2-
execute if score music_progress time matches 729 run function minecraft:tone/7
execute if score music_progress time matches 729 run function minecraft:tone/5
execute if score music_progress time matches 729 run function minecraft:tone/5-

execute if score music_progress time matches 735 run function minecraft:tone/2

execute if score music_progress time matches 741 run function minecraft:tone/5-
execute if score music_progress time matches 741 run function minecraft:tone/2-
execute if score music_progress time matches 741 run function minecraft:tone/7
execute if score music_progress time matches 741 run function minecraft:tone/5

execute if score music_progress time matches 753 run function minecraft:tone/2-
execute if score music_progress time matches 753 run function minecraft:tone/7
execute if score music_progress time matches 753 run function minecraft:tone/-3

execute if score music_progress time matches 759 run function minecraft:tone/5.5-
execute if score music_progress time matches 759 run function minecraft:tone/7
execute if score music_progress time matches 759 run function minecraft:tone/-7

execute if score music_progress time matches 765 run function minecraft:tone/6-
execute if score music_progress time matches 765 run function minecraft:tone/3

execute if score music_progress time matches 771 run function minecraft:tone/7-

execute if score music_progress time matches 777 run function minecraft:tone/3-
execute if score music_progress time matches 777 run function minecraft:tone/-6

execute if score music_progress time matches 780 run function minecraft:tone/1--

execute if score music_progress time matches 783 run function minecraft:tone/2-
execute if score music_progress time matches 783 run function minecraft:tone/3

execute if score music_progress time matches 786 run function minecraft:tone/7-

execute if score music_progress time matches 789 run function minecraft:tone/-1
execute if score music_progress time matches 789 run function minecraft:tone/6

execute if score music_progress time matches 792 run function minecraft:tone/6-

execute if score music_progress time matches 795 run function minecraft:tone/7

execute if score music_progress time matches 798 run function minecraft:tone/5.5-

execute if score music_progress time matches 801 run function minecraft:tone/6-
execute if score music_progress time matches 801 run function minecraft:tone/-4

execute if score music_progress time matches 804 run function minecraft:tone/3--

execute if score music_progress time matches 807 run function minecraft:tone/2--
execute if score music_progress time matches 807 run function minecraft:tone/1

execute if score music_progress time matches 810 run function minecraft:tone/3--

execute if score music_progress time matches 813 run function minecraft:tone/6-
execute if score music_progress time matches 813 run function minecraft:tone/4

execute if score music_progress time matches 816 run function minecraft:tone/3--

execute if score music_progress time matches 819 run function minecraft:tone/2--

execute if score music_progress time matches 822 run function minecraft:tone/3--

execute if score music_progress time matches 825 run function minecraft:tone/6-
execute if score music_progress time matches 825 run function minecraft:tone/-5

execute if score music_progress time matches 828 run function minecraft:tone/3--

execute if score music_progress time matches 831 run function minecraft:tone/2--
execute if score music_progress time matches 831 run function minecraft:tone/2

execute if score music_progress time matches 834 run function minecraft:tone/3--

execute if score music_progress time matches 837 run function minecraft:tone/6-
execute if score music_progress time matches 837 run function minecraft:tone/5

execute if score music_progress time matches 840 run function minecraft:tone/3--

execute if score music_progress time matches 843 run function minecraft:tone/2--

execute if score music_progress time matches 846 run function minecraft:tone/3--

execute if score music_progress time matches 849 run function minecraft:tone/6-
execute if score music_progress time matches 849 run function minecraft:tone/-6

execute if score music_progress time matches 852 run function minecraft:tone/3--

execute if score music_progress time matches 855 run function minecraft:tone/1.5--
execute if score music_progress time matches 855 run function minecraft:tone/3

execute if score music_progress time matches 858 run function minecraft:tone/3--

execute if score music_progress time matches 861 run function minecraft:tone/6-
execute if score music_progress time matches 861 run function minecraft:tone/6

execute if score music_progress time matches 864 run function minecraft:tone/3--

execute if score music_progress time matches 867 run function minecraft:tone/1--
execute if score music_progress time matches 867 run function minecraft:tone/7

execute if score music_progress time matches 870 run function minecraft:tone/3--

execute if score music_progress time matches 873 run function minecraft:tone/6-
execute if score music_progress time matches 873 run function minecraft:tone/1.5-

execute if score music_progress time matches 876 run function minecraft:tone/3--

execute if score music_progress time matches 879 run function minecraft:tone/1--

execute if score music_progress time matches 882 run function minecraft:tone/3--

execute if score music_progress time matches 885 run function minecraft:tone/6-

execute if score music_progress time matches 888 run function minecraft:tone/3--

execute if score music_progress time matches 891 run function minecraft:tone/1--

execute if score music_progress time matches 894 run function minecraft:tone/3--

execute if score music_progress time matches 897 run function minecraft:tone/1--
execute if score music_progress time matches 897 run function minecraft:tone/--6

execute if score music_progress time matches 900 run function minecraft:tone/3-
execute if score music_progress time matches 900 run function minecraft:tone/-3

execute if score music_progress time matches 903 run function minecraft:tone/7-
execute if score music_progress time matches 903 run function minecraft:tone/-6

execute if score music_progress time matches 906 run function minecraft:tone/3-
execute if score music_progress time matches 906 run function minecraft:tone/-7

execute if score music_progress time matches 909 run function minecraft:tone/1--
execute if score music_progress time matches 909 run function minecraft:tone/1

execute if score music_progress time matches 912 run function minecraft:tone/3-

execute if score music_progress time matches 915 run function minecraft:tone/2--
execute if score music_progress time matches 915 run function minecraft:tone/3

execute if score music_progress time matches 918 run function minecraft:tone/3-

execute if score music_progress time matches 921 run function minecraft:tone/7-
execute if score music_progress time matches 921 run function minecraft:tone/-3

execute if score music_progress time matches 924 run function minecraft:tone/7

execute if score music_progress time matches 927 run function minecraft:tone/6-
execute if score music_progress time matches 927 run function minecraft:tone/-7

execute if score music_progress time matches 930 run function minecraft:tone/7

execute if score music_progress time matches 933 run function minecraft:tone/5-
execute if score music_progress time matches 933 run function minecraft:tone/5
execute if score music_progress time matches 933 run function minecraft:tone/3

execute if score music_progress time matches 939 run function minecraft:tone/3-

execute if score music_progress time matches 942 run function minecraft:tone/5-

execute if score music_progress time matches 945 run function minecraft:tone/6-
execute if score music_progress time matches 945 run function minecraft:tone/--4

execute if score music_progress time matches 948 run function minecraft:tone/1-
execute if score music_progress time matches 948 run function minecraft:tone/-1

execute if score music_progress time matches 951 run function minecraft:tone/5-
execute if score music_progress time matches 951 run function minecraft:tone/-4

execute if score music_progress time matches 954 run function minecraft:tone/1-
execute if score music_progress time matches 954 run function minecraft:tone/-5

execute if score music_progress time matches 957 run function minecraft:tone/6-
execute if score music_progress time matches 957 run function minecraft:tone/-6

execute if score music_progress time matches 960 run function minecraft:tone/1-

execute if score music_progress time matches 963 run function minecraft:tone/1--
execute if score music_progress time matches 963 run function minecraft:tone/1

execute if score music_progress time matches 966 run function minecraft:tone/1-

execute if score music_progress time matches 969 run function minecraft:tone/5-
execute if score music_progress time matches 969 run function minecraft:tone/-1

execute if score music_progress time matches 972 run function minecraft:tone/1-

execute if score music_progress time matches 975 run function minecraft:tone/4-
execute if score music_progress time matches 975 run function minecraft:tone/-5

execute if score music_progress time matches 978 run function minecraft:tone/1-

execute if score music_progress time matches 981 run function minecraft:tone/3-
execute if score music_progress time matches 981 run function minecraft:tone/3
execute if score music_progress time matches 981 run function minecraft:tone/1

execute if score music_progress time matches 987 run function minecraft:tone/3-

execute if score music_progress time matches 990 run function minecraft:tone/5-

execute if score music_progress time matches 993 run function minecraft:tone/4-
execute if score music_progress time matches 993 run function minecraft:tone/-2
execute if score music_progress time matches 993 run function minecraft:tone/--2

execute if score music_progress time matches 996 run function minecraft:tone/6

execute if score music_progress time matches 999 run function minecraft:tone/3-
execute if score music_progress time matches 999 run function minecraft:tone/-6

execute if score music_progress time matches 1002 run function minecraft:tone/6

execute if score music_progress time matches 1005 run function minecraft:tone/2-
execute if score music_progress time matches 1005 run function minecraft:tone/4

execute if score music_progress time matches 1008 run function minecraft:tone/6
execute if score music_progress time matches 1008 run function minecraft:tone/3

execute if score music_progress time matches 1011 run function minecraft:tone/4-
execute if score music_progress time matches 1011 run function minecraft:tone/2

execute if score music_progress time matches 1014 run function minecraft:tone/6
execute if score music_progress time matches 1014 run function minecraft:tone/1

execute if score music_progress time matches 1017 run function minecraft:tone/3-
execute if score music_progress time matches 1017 run function minecraft:tone/--6
execute if score music_progress time matches 1017 run function minecraft:tone/---6

execute if score music_progress time matches 1020 run function minecraft:tone/3

execute if score music_progress time matches 1023 run function minecraft:tone/2-
execute if score music_progress time matches 1023 run function minecraft:tone/--3

execute if score music_progress time matches 1026 run function minecraft:tone/3

execute if score music_progress time matches 1029 run function minecraft:tone/1-
execute if score music_progress time matches 1029 run function minecraft:tone/-3

execute if score music_progress time matches 1032 run function minecraft:tone/3
execute if score music_progress time matches 1032 run function minecraft:tone/-2

execute if score music_progress time matches 1035 run function minecraft:tone/3-
execute if score music_progress time matches 1035 run function minecraft:tone/-1

execute if score music_progress time matches 1038 run function minecraft:tone/3
execute if score music_progress time matches 1038 run function minecraft:tone/--7

execute if score music_progress time matches 1041 run function minecraft:tone/2-
execute if score music_progress time matches 1041 run function minecraft:tone/--7
execute if score music_progress time matches 1041 run function minecraft:tone/---7

execute if score music_progress time matches 1044 run function minecraft:tone/4

execute if score music_progress time matches 1047 run function minecraft:tone/1-
execute if score music_progress time matches 1047 run function minecraft:tone/-4

execute if score music_progress time matches 1050 run function minecraft:tone/4

execute if score music_progress time matches 1053 run function minecraft:tone/7
execute if score music_progress time matches 1053 run function minecraft:tone/2
execute if score music_progress time matches 1053 run function minecraft:tone/-7

execute if score music_progress time matches 1056 run function minecraft:tone/4

execute if score music_progress time matches 1059 run function minecraft:tone/6
execute if score music_progress time matches 1059 run function minecraft:tone/-4

execute if score music_progress time matches 1062 run function minecraft:tone/4

execute if score music_progress time matches 1065 run function minecraft:tone/5.5
execute if score music_progress time matches 1065 run function minecraft:tone/4
execute if score music_progress time matches 1065 run function minecraft:tone/2
execute if score music_progress time matches 1065 run function minecraft:tone/-2

execute if score music_progress time matches 1071 run function minecraft:tone/6
execute if score music_progress time matches 1071 run function minecraft:tone/4
execute if score music_progress time matches 1071 run function minecraft:tone/1
execute if score music_progress time matches 1071 run function minecraft:tone/-1

execute if score music_progress time matches 1077 run function minecraft:tone/7
execute if score music_progress time matches 1077 run function minecraft:tone/3
execute if score music_progress time matches 1077 run function minecraft:tone/-7
execute if score music_progress time matches 1077 run function minecraft:tone/--7

execute if score music_progress time matches 1083 run function minecraft:tone/-3
execute if score music_progress time matches 1083 run function minecraft:tone/--3

execute if score music_progress time matches 1089 run function minecraft:tone/1-
execute if score music_progress time matches 1089 run function minecraft:tone/--6

execute if score music_progress time matches 1092 run function minecraft:tone/3
execute if score music_progress time matches 1092 run function minecraft:tone/-3

execute if score music_progress time matches 1095 run function minecraft:tone/7
execute if score music_progress time matches 1095 run function minecraft:tone/-6

execute if score music_progress time matches 1098 run function minecraft:tone/3
execute if score music_progress time matches 1098 run function minecraft:tone/-7

execute if score music_progress time matches 1101 run function minecraft:tone/1-
execute if score music_progress time matches 1101 run function minecraft:tone/1

execute if score music_progress time matches 1104 run function minecraft:tone/3
execute if score music_progress time matches 1104 run function minecraft:tone/-7

execute if score music_progress time matches 1107 run function minecraft:tone/2-
execute if score music_progress time matches 1107 run function minecraft:tone/-6

execute if score music_progress time matches 1110 run function minecraft:tone/3
execute if score music_progress time matches 1110 run function minecraft:tone/-3

execute if score music_progress time matches 1113 run function minecraft:tone/7
execute if score music_progress time matches 1113 run function minecraft:tone/--3

execute if score music_progress time matches 1116 run function minecraft:tone/3

execute if score music_progress time matches 1119 run function minecraft:tone/6
execute if score music_progress time matches 1119 run function minecraft:tone/--7

execute if score music_progress time matches 1122 run function minecraft:tone/3

execute if score music_progress time matches 1125 run function minecraft:tone/5

execute if score music_progress time matches 1131 run function minecraft:tone/3
execute if score music_progress time matches 1131 run function minecraft:tone/--7

execute if score music_progress time matches 1134 run function minecraft:tone/5

execute if score music_progress time matches 1137 run function minecraft:tone/6
execute if score music_progress time matches 1137 run function minecraft:tone/--4

execute if score music_progress time matches 1140 run function minecraft:tone/1
execute if score music_progress time matches 1140 run function minecraft:tone/-1

execute if score music_progress time matches 1143 run function minecraft:tone/5
execute if score music_progress time matches 1143 run function minecraft:tone/-4

execute if score music_progress time matches 1146 run function minecraft:tone/1
execute if score music_progress time matches 1146 run function minecraft:tone/-5

execute if score music_progress time matches 1149 run function minecraft:tone/6
execute if score music_progress time matches 1149 run function minecraft:tone/-6

execute if score music_progress time matches 1152 run function minecraft:tone/1
execute if score music_progress time matches 1152 run function minecraft:tone/-5

execute if score music_progress time matches 1155 run function minecraft:tone/1-
execute if score music_progress time matches 1155 run function minecraft:tone/-4

execute if score music_progress time matches 1158 run function minecraft:tone/1
execute if score music_progress time matches 1158 run function minecraft:tone/-1

execute if score music_progress time matches 1161 run function minecraft:tone/5
execute if score music_progress time matches 1161 run function minecraft:tone/--1

execute if score music_progress time matches 1164 run function minecraft:tone/1

execute if score music_progress time matches 1167 run function minecraft:tone/4
execute if score music_progress time matches 1167 run function minecraft:tone/--5

execute if score music_progress time matches 1170 run function minecraft:tone/1

execute if score music_progress time matches 1173 run function minecraft:tone/-3

execute if score music_progress time matches 1179 run function minecraft:tone/3
execute if score music_progress time matches 1179 run function minecraft:tone/--5

execute if score music_progress time matches 1182 run function minecraft:tone/5

execute if score music_progress time matches 1185 run function minecraft:tone/4
execute if score music_progress time matches 1185 run function minecraft:tone/--2

execute if score music_progress time matches 1188 run function minecraft:tone/--6

execute if score music_progress time matches 1191 run function minecraft:tone/4-
execute if score music_progress time matches 1191 run function minecraft:tone/-2

execute if score music_progress time matches 1194 run function minecraft:tone/3-
execute if score music_progress time matches 1194 run function minecraft:tone/-3

execute if score music_progress time matches 1197 run function minecraft:tone/2-
execute if score music_progress time matches 1197 run function minecraft:tone/-4

execute if score music_progress time matches 1200 run function minecraft:tone/1-
execute if score music_progress time matches 1200 run function minecraft:tone/-3

execute if score music_progress time matches 1203 run function minecraft:tone/7
execute if score music_progress time matches 1203 run function minecraft:tone/-2

execute if score music_progress time matches 1206 run function minecraft:tone/6

execute if score music_progress time matches 1209 run function minecraft:tone/3-
execute if score music_progress time matches 1209 run function minecraft:tone/---6

execute if score music_progress time matches 1212 run function minecraft:tone/2-
execute if score music_progress time matches 1212 run function minecraft:tone/--3

execute if score music_progress time matches 1215 run function minecraft:tone/3-
execute if score music_progress time matches 1215 run function minecraft:tone/--6

execute if score music_progress time matches 1218 run function minecraft:tone/4-
execute if score music_progress time matches 1218 run function minecraft:tone/--7

execute if score music_progress time matches 1221 run function minecraft:tone/3-
execute if score music_progress time matches 1221 run function minecraft:tone/-1

execute if score music_progress time matches 1224 run function minecraft:tone/2-
execute if score music_progress time matches 1224 run function minecraft:tone/-2

execute if score music_progress time matches 1227 run function minecraft:tone/1-
execute if score music_progress time matches 1227 run function minecraft:tone/-3

execute if score music_progress time matches 1230 run function minecraft:tone/7

execute if score music_progress time matches 1233 run function minecraft:tone/6
execute if score music_progress time matches 1233 run function minecraft:tone/-2
execute if score music_progress time matches 1233 run function minecraft:tone/--2

execute if score music_progress time matches 1239 run function minecraft:tone/3-

execute if score music_progress time matches 1245 run function minecraft:tone/5.5
execute if score music_progress time matches 1245 run function minecraft:tone/--7
execute if score music_progress time matches 1245 run function minecraft:tone/---7

execute if score music_progress time matches 1251 run function minecraft:tone/3-

execute if score music_progress time matches 1254 run function minecraft:tone/--6
execute if score music_progress time matches 1254 run function minecraft:tone/---6

execute if score music_progress time matches 1257 run function minecraft:tone/6
execute if score music_progress time matches 1257 run function minecraft:tone/--6
execute if score music_progress time matches 1257 run function minecraft:tone/---6

execute if score music_progress time matches 1263 run function minecraft:tone/-3

execute if score music_progress time matches 1269 run function minecraft:tone/-6

execute if score music_progress time matches 1283 run function minecraft:tone/3-
execute if score music_progress time matches 1283 run function minecraft:tone/-4

execute if score music_progress time matches 1291 run function minecraft:tone/2-
execute if score music_progress time matches 1291 run function minecraft:tone/1

execute if score music_progress time matches 1299 run function minecraft:tone/6-
execute if score music_progress time matches 1299 run function minecraft:tone/4

execute if score music_progress time matches 1307 run function minecraft:tone/2-
execute if score music_progress time matches 1307 run function minecraft:tone/5

execute if score music_progress time matches 1315 run function minecraft:tone/3-
execute if score music_progress time matches 1315 run function minecraft:tone/6

execute if score music_progress time matches 1323 run function minecraft:tone/2-

execute if score music_progress time matches 1331 run function minecraft:tone/6

execute if score music_progress time matches 1339 run function minecraft:tone/2-

execute if score music_progress time matches 1347 run function minecraft:tone/3-
execute if score music_progress time matches 1347 run function minecraft:tone/-5

execute if score music_progress time matches 1355 run function minecraft:tone/2-
execute if score music_progress time matches 1355 run function minecraft:tone/2

execute if score music_progress time matches 1363 run function minecraft:tone/6-
execute if score music_progress time matches 1363 run function minecraft:tone/5

execute if score music_progress time matches 1371 run function minecraft:tone/2-
execute if score music_progress time matches 1371 run function minecraft:tone/6

execute if score music_progress time matches 1379 run function minecraft:tone/3-
execute if score music_progress time matches 1379 run function minecraft:tone/7

execute if score music_progress time matches 1387 run function minecraft:tone/2-

execute if score music_progress time matches 1395 run function minecraft:tone/6

execute if score music_progress time matches 1403 run function minecraft:tone/2-

execute if score music_progress time matches 1411 run function minecraft:tone/3-
execute if score music_progress time matches 1411 run function minecraft:tone/-6

execute if score music_progress time matches 1415 run function minecraft:tone/2--
execute if score music_progress time matches 1415 run function minecraft:tone/7-

execute if score music_progress time matches 1419 run function minecraft:tone/3--
execute if score music_progress time matches 1419 run function minecraft:tone/1--
execute if score music_progress time matches 1419 run function minecraft:tone/2-
execute if score music_progress time matches 1419 run function minecraft:tone/3

execute if score music_progress time matches 1427 run function minecraft:tone/6-
execute if score music_progress time matches 1427 run function minecraft:tone/6

execute if score music_progress time matches 1435 run function minecraft:tone/2-
execute if score music_progress time matches 1435 run function minecraft:tone/7

execute if score music_progress time matches 1443 run function minecraft:tone/3-
execute if score music_progress time matches 1443 run function minecraft:tone/1-

execute if score music_progress time matches 1451 run function minecraft:tone/2-

execute if score music_progress time matches 1459 run function minecraft:tone/6

execute if score music_progress time matches 1467 run function minecraft:tone/2-

execute if score music_progress time matches 1475 run function minecraft:tone/3-

execute if score music_progress time matches 1483 run function minecraft:tone/2-

execute if score music_progress time matches 1491 run function minecraft:tone/6-

execute if score music_progress time matches 1499 run function minecraft:tone/2-

execute if score music_progress time matches 1507 run function minecraft:tone/3-

execute if score music_progress time matches 1515 run function minecraft:tone/2-

execute if score music_progress time matches 1523 run function minecraft:tone/6

execute if score music_progress time matches 1531 run function minecraft:tone/2-

execute if score music_progress time matches 1539 run function minecraft:tone/3-
execute if score music_progress time matches 1539 run function minecraft:tone/-4

execute if score music_progress time matches 1547 run function minecraft:tone/2-
execute if score music_progress time matches 1547 run function minecraft:tone/1

execute if score music_progress time matches 1555 run function minecraft:tone/6-
execute if score music_progress time matches 1555 run function minecraft:tone/4

execute if score music_progress time matches 1563 run function minecraft:tone/2-
execute if score music_progress time matches 1563 run function minecraft:tone/5

execute if score music_progress time matches 1571 run function minecraft:tone/3-
execute if score music_progress time matches 1571 run function minecraft:tone/6

execute if score music_progress time matches 1579 run function minecraft:tone/2-

execute if score music_progress time matches 1587 run function minecraft:tone/6

execute if score music_progress time matches 1595 run function minecraft:tone/2-

execute if score music_progress time matches 1603 run function minecraft:tone/3-
execute if score music_progress time matches 1603 run function minecraft:tone/-5

execute if score music_progress time matches 1611 run function minecraft:tone/2-
execute if score music_progress time matches 1611 run function minecraft:tone/2

execute if score music_progress time matches 1619 run function minecraft:tone/6-
execute if score music_progress time matches 1619 run function minecraft:tone/5

execute if score music_progress time matches 1627 run function minecraft:tone/2-
execute if score music_progress time matches 1627 run function minecraft:tone/6

execute if score music_progress time matches 1635 run function minecraft:tone/3-
execute if score music_progress time matches 1635 run function minecraft:tone/7

execute if score music_progress time matches 1643 run function minecraft:tone/2-

execute if score music_progress time matches 1651 run function minecraft:tone/6

execute if score music_progress time matches 1659 run function minecraft:tone/2-

execute if score music_progress time matches 1667 run function minecraft:tone/3-
execute if score music_progress time matches 1667 run function minecraft:tone/-6

execute if score music_progress time matches 1671 run function minecraft:tone/2--
execute if score music_progress time matches 1671 run function minecraft:tone/7-

execute if score music_progress time matches 1675 run function minecraft:tone/3--
execute if score music_progress time matches 1675 run function minecraft:tone/1--
execute if score music_progress time matches 1675 run function minecraft:tone/2-
execute if score music_progress time matches 1675 run function minecraft:tone/3

execute if score music_progress time matches 1683 run function minecraft:tone/6-
execute if score music_progress time matches 1683 run function minecraft:tone/6

execute if score music_progress time matches 1691 run function minecraft:tone/2-
execute if score music_progress time matches 1691 run function minecraft:tone/7

execute if score music_progress time matches 1699 run function minecraft:tone/3-
execute if score music_progress time matches 1699 run function minecraft:tone/1-

execute if score music_progress time matches 1707 run function minecraft:tone/2-

execute if score music_progress time matches 1715 run function minecraft:tone/6

execute if score music_progress time matches 1723 run function minecraft:tone/2-

execute if score music_progress time matches 1731 run function minecraft:tone/3-
execute if score music_progress time matches 1731 run function minecraft:tone/-5

execute if score music_progress time matches 1739 run function minecraft:tone/2-
execute if score music_progress time matches 1739 run function minecraft:tone/2

execute if score music_progress time matches 1747 run function minecraft:tone/6-
execute if score music_progress time matches 1747 run function minecraft:tone/5

execute if score music_progress time matches 1755 run function minecraft:tone/2-
execute if score music_progress time matches 1755 run function minecraft:tone/6

execute if score music_progress time matches 1763 run function minecraft:tone/3-
execute if score music_progress time matches 1763 run function minecraft:tone/7

execute if score music_progress time matches 1771 run function minecraft:tone/2-

execute if score music_progress time matches 1779 run function minecraft:tone/6

execute if score music_progress time matches 1787 run function minecraft:tone/2-

execute if score music_progress time matches 1795 run function minecraft:tone/3-
execute if score music_progress time matches 1795 run function minecraft:tone/-6

execute if score music_progress time matches 1803 run function minecraft:tone/2-
execute if score music_progress time matches 1803 run function minecraft:tone/3

execute if score music_progress time matches 1811 run function minecraft:tone/6-
execute if score music_progress time matches 1811 run function minecraft:tone/6

execute if score music_progress time matches 1819 run function minecraft:tone/2-
execute if score music_progress time matches 1819 run function minecraft:tone/7

execute if score music_progress time matches 1827 run function minecraft:tone/3-
execute if score music_progress time matches 1827 run function minecraft:tone/1-

execute if score music_progress time matches 1835 run function minecraft:tone/2-

execute if score music_progress time matches 1843 run function minecraft:tone/6

execute if score music_progress time matches 1851 run function minecraft:tone/2-

execute if score music_progress time matches 1859 run function minecraft:tone/3-

execute if score music_progress time matches 1867 run function minecraft:tone/2-

execute if score music_progress time matches 1875 run function minecraft:tone/6-

execute if score music_progress time matches 1883 run function minecraft:tone/2-

execute if score music_progress time matches 1891 run function minecraft:tone/3-

execute if score music_progress time matches 1899 run function minecraft:tone/2-

execute if score music_progress time matches 1907 run function minecraft:tone/6

execute if score music_progress time matches 1915 run function minecraft:tone/2-

execute if score music_progress time matches 1923 run function minecraft:tone/2-

execute if score music_progress music_type matches 1..4 if score music_progress time matches 1934.. run function minecraft:music/kagec3/play
execute if score music_progress music_type matches 1..4 if score music_progress time matches 1934.. run scoreboard players set music_progress time 0