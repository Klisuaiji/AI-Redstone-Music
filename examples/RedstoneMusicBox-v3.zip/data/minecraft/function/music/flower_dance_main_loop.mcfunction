
#播放
execute if score music_progress music_type matches 1..4 run function minecraft:music/flower_dance


execute if score music_progress music_type matches 1..4 run scoreboard players add music_progress time 1
execute unless score music_progress music_type matches 1.. run scoreboard players set music_progress time -20
execute unless score music_progress music_type matches 1.. run scoreboard players set music_progress music_type 1