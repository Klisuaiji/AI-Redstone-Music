scoreboard players set music_progress music_type 17
scoreboard players set music_progress nbs_s 0
scoreboard players set music_progress nbs_t -1
