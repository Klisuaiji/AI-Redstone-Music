execute if score music_progress music_type matches 17 run scoreboard players operation music_progress nbs_s += #speed nbs_s
execute if score music_progress music_type matches 17 run function minecraft:music/after_the_rain/tree/0_8191
