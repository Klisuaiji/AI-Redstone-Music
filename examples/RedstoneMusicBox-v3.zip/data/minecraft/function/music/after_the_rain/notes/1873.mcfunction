execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 0.7 0.629961 1
scoreboard players set music_progress nbs_t 1873
