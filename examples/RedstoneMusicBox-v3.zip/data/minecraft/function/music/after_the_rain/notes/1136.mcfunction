execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 0.668 1.059463 1
scoreboard players set music_progress nbs_t 1136
