execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 0.433 0.793701 1
scoreboard players set music_progress nbs_t 1126
