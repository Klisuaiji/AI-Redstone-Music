execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 0.753 1.259921 1
scoreboard players set music_progress nbs_t 2234
