execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 0.541 0.707107 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 0.488 0.793701 1
execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 0.515 1.681793 1
scoreboard players set music_progress nbs_t 2090
