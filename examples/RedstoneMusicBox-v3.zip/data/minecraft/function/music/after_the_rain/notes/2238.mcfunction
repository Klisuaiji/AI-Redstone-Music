execute as @a[tag=!no_music] at @s run playsound minecraft:block.note_block.guitar voice @s ^0 ^ ^ 0.691 0.561231 1
scoreboard players set music_progress nbs_t 2238
