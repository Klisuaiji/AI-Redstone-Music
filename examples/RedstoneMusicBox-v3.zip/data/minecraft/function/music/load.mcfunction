say §a红石音乐盒数据包已加载！ §e[版本：v3 兼容 1.21.2-1.21.8 / 26.2]
scoreboard objectives remove time
scoreboard objectives remove nbs_s
scoreboard objectives remove music_type
scoreboard objectives remove nbs_t
scoreboard objectives add time dummy
scoreboard objectives add nbs_s dummy
scoreboard objectives add music_type dummy
scoreboard objectives add nbs_t dummy
scoreboard players set #speed nbs_s 80
scoreboard objectives remove mb_menu
scoreboard objectives remove mb_lyc
scoreboard objectives remove mb_song
scoreboard objectives remove mb_kagec3
scoreboard objectives remove mb_sanyaose
scoreboard objectives remove mb_touhoukami
scoreboard objectives remove mb_lemon
scoreboard objectives remove mb_afterrain
scoreboard objectives remove mb_baka
scoreboard objectives remove mb_badapple
scoreboard objectives remove mb_lunatic
scoreboard objectives remove mb_popcorn
scoreboard objectives remove mb_un
scoreboard objectives remove mb_shanghaitea
scoreboard objectives remove mb_pulse
scoreboard objectives remove mb_rcnt
scoreboard objectives remove mb_ucnt
scoreboard objectives remove mb_udone
scoreboard objectives remove mb_hold
scoreboard objectives remove mb_hcnt
scoreboard objectives remove mb_done
scoreboard objectives remove mb_seq
scoreboard objectives remove mb_cfg
scoreboard objectives remove mb_dim
scoreboard objectives remove redstonemusic:menu
scoreboard objectives remove lrc
scoreboard objectives remove play
scoreboard objectives remove mb_fanwutuobang
scoreboard objectives add mb_menu trigger
scoreboard objectives add mb_lyc trigger
scoreboard objectives add mb_song trigger
scoreboard objectives add mb_kagec3 trigger
scoreboard objectives add mb_sanyaose trigger
scoreboard objectives add mb_touhoukami trigger
scoreboard objectives add mb_lemon trigger
scoreboard objectives add mb_afterrain trigger
scoreboard objectives add mb_baka trigger
scoreboard objectives add mb_badapple trigger
scoreboard objectives add mb_lunatic trigger
scoreboard objectives add mb_popcorn trigger
scoreboard objectives add mb_un trigger
scoreboard objectives add mb_shanghaitea trigger
scoreboard objectives add mb_pulse dummy
scoreboard objectives add mb_rcnt dummy
scoreboard objectives add mb_ucnt dummy
scoreboard objectives add mb_udone dummy
scoreboard objectives add mb_hold dummy
scoreboard objectives add mb_hcnt dummy
scoreboard objectives add mb_done dummy
scoreboard objectives add mb_seq dummy
scoreboard objectives add mb_cfg dummy
scoreboard objectives add mb_dim dummy
scoreboard objectives add redstonemusic:menu trigger
scoreboard objectives add lrc trigger
scoreboard objectives add play trigger
scoreboard objectives add mb_fanwutuobang trigger
scoreboard players set #mb_pause mb_cfg 0
scoreboard players set #mb_banning mb_cfg 0
scoreboard players set #ban mb_cfg 1
scoreboard players set #dim_o mb_cfg 0
scoreboard players set #dim_n mb_cfg 0
scoreboard players set #dim_e mb_cfg 0
scoreboard players set #dim_any mb_cfg 0
scoreboard players enable @a mb_menu
scoreboard players enable @a mb_lyc
scoreboard players enable @a mb_song
scoreboard players enable @a mb_kagec3
scoreboard players enable @a mb_sanyaose
scoreboard players enable @a mb_touhoukami
scoreboard players enable @a mb_lemon
scoreboard players enable @a mb_afterrain
scoreboard players enable @a mb_baka
scoreboard players enable @a mb_badapple
scoreboard players enable @a mb_lunatic
scoreboard players enable @a mb_popcorn
scoreboard players enable @a mb_un
scoreboard players enable @a mb_shanghaitea
scoreboard players enable @a redstonemusic:menu
scoreboard players enable @a lrc
scoreboard players enable @a play
scoreboard players enable @a mb_fanwutuobang
title @a title "已成功加载音乐数据包"
title @a subtitle "输入 /trigger menu 获取红石音乐盒"
tellraw @a ["[音乐盒] 已成功加载音乐数据包，输入 /trigger menu 获取唱片机；再输入 /trigger menu 可再次获得"]
